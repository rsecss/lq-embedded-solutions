#include "tim_app.h"

/**
 * @brief   设置 PWM 占空比
 * 
 * 此函数用于设置 TIMX 的 CHX 通道的 PWM 占空比。占空比的范围为 0%~100%
 * 
 * @param   Duty 占空比，范围为 0.0~100.0
 * @param   channel 定时器通道号（1 对应 htim16，2 对应 htim17）
 * @retval  无
 */
void pwm_set_duty(float duty,uint8_t channel)
{
    switch(channel)
    {
        case 1:
            TIM16->CCR1 = (TIM16->ARR + 1) * (duty / 100.0f);
            break;
        case 2:
            TIM17->CCR1 = (TIM17->ARR + 1) * (duty / 100.0f);
            break;
        default:
            break;
    }
}

/**
 * @brief   设置 PWM 频率
 * 
 * @param   frequency 目标频率（Hz）
 * @param   channel 定时器通道号（1 对应 htim16，2 对应 htim17）
 */
void pwm_set_frequency(int frequency, uint8_t channel)
{
    uint32_t clk = HAL_RCC_GetPCLK2Freq();  // 获取 PCLK2 时钟频率
    if ((RCC->CFGR & RCC_CFGR_PPRE2) != RCC_CFGR_PPRE2_DIV1) {
        clk *= 2;
    }
    
    float duty = 0;
    uint32_t prescaler = 1;
    uint32_t arr_value = 0;
    
    // 计算ARR和预分频器
    arr_value = clk / (frequency * prescaler) - 1;
    
    // 如果 ARR 超出范围，调整预分频器
    if (arr_value > 65535) {
        prescaler = (arr_value + 65535) / 65535;
        arr_value = clk / (frequency * prescaler) - 1;
        // printf("Using prescaler = %d\r\n", prescaler);
    }

    // printf("Target Frequency = %d Hz\r\n", frequency);
    // printf("Clock = %d Hz\r\n", clk);
    // printf("ARR = %d\r\n", arr);
    
    switch (channel) {
        case 1:
            /* 保存原占空比 */
            duty = (float)TIM16->CCR1 / (TIM16->ARR + 1);
            // printf("Original duty for channel 1 = %.3f\r\n", duty);
            
            /* 设置新的预分频值和 ARR */
            __HAL_TIM_SET_PRESCALER(&htim16, prescaler-1);
            TIM16->ARR = arr_value;
            // printf("New TIM16->ARR = %d\r\n", TIM16->ARR);
            
            /* 保持占空比不变 */
            TIM16->CCR1 = (TIM16->ARR + 1) * duty;
            // printf("New TIM16->CCR1 = %d\r\n", TIM16->CCR1);
            
            /* 更新寄存器 */
            TIM16->EGR = TIM_EGR_UG;
            break;
            
        case 2:
            /* 保存原占空比 */
            duty = (float)TIM17->CCR1 / (TIM17->ARR + 1);
            // printf("Original duty for channel 2 = %.3f\r\n", duty);
            
            /* 设置新的预分频值和 ARR */
            __HAL_TIM_SET_PRESCALER(&htim17, prescaler-1);
            TIM17->ARR = arr_value;
            // printf("New TIM17->ARR = %d\r\n", TIM17->ARR);
            
            /* 保持占空比不变 */
            TIM17->CCR1 = (TIM17->ARR + 1) * duty;
            // printf("New TIM17->CCR1 = %d\r\n", TIM17->CCR1);
            
            /* 更新寄存器 */
            TIM17->EGR = TIM_EGR_UG;
            break;
        default:
            printf("Invalid channel number\r\n");
            break;
    }
}

#define BUFFER_SIZE 30
#define WINDOW_SIZE_MS 3000

typedef struct {
    uint32_t timestamp;     // 采集到的时间戳
    uint32_t frequency;     // 采集到的频率
}frequency_data_t;

typedef struct {
    frequency_data_t buffer[BUFFER_SIZE];   // 数据存储
    int32_t start;                          // 缓冲区起始位置
    int32_t end;                            // 缓冲区结束位置
}frequency_buffer_t;

frequency_buffer_t buffer_a = {0};
frequency_buffer_t buffer_b = {0};

uint8_t sudden_change_detected_flag[2] = {0};      // 频率突变标志

/**
 * @brief       添加数据到缓冲区
 * 
 * @param       buf 缓冲区结构体指针
 * @param       frequency 
 * @param       current_time 当前时间戳
 * @retval      无
 */
void add_data_to_buffer(frequency_buffer_t *buf, uint32_t frequency, uint32_t current_time) 
{
    buf->buffer[buf->end].timestamp = current_time; // 将当前时间戳添加到缓冲区
    buf->buffer[buf->end].frequency = frequency;    // 将当前频率添加到缓冲区
    buf->end = (buf->end + 1) % BUFFER_SIZE;        // 更新缓冲区结束位置

    /* 如果缓冲区已满，则更新缓冲区起始位置 */
    if (buf->end == buf->start) {
        buf->start = (buf->start + 1) % BUFFER_SIZE;
    }

    /* 移除超出 3 秒窗口的数据 */
    while (current_time - buf->buffer[buf->start].timestamp > WINDOW_SIZE_MS) {
        buf->start = (buf->start + 1) % BUFFER_SIZE;
    }
}

/**
 * @brief       检查频率突变
 * 
 * @param       sudden_change_count 频率突变计数
 * @param       buf 缓冲区结构体指针
 * @retval      无
 */
void check_frequency_sudden_change(uint8_t *sudden_change_count, frequency_buffer_t *buf, uint8_t channel_index)
{
    /* 如果缓冲区为空，则返回 */
    if (buf->end == buf->start) {
        return;
    }

    uint32_t f_max = buf->buffer[buf->start].frequency;
    uint32_t f_min = buf->buffer[buf->start].frequency;
    int32_t index = buf->start;

    /* 遍历缓冲区，计算最大值和最小值 */
    while (index != buf->end) {
        if (buf->buffer[index].frequency > f_max) {
            f_max = buf->buffer[index].frequency;
        } else if (buf->buffer[index].frequency < f_min) {
            f_min = buf->buffer[index].frequency;
        }

        index = (index + 1) % BUFFER_SIZE;
    }

    /* 计算频率差值 */
    uint32_t diff = f_max - f_min;

    /* 检查频率突变 */
    if (diff < param_arrays[0]) {
        sudden_change_detected_flag[channel_index] = 1;
    } else if (sudden_change_detected_flag[channel_index] == 1) {
        sudden_change_detected_flag[channel_index] = 0;
        (*sudden_change_count)++;
    }
}

uint32_t tim_ic_buffer[2][64] = {0};         // 定义存储输入捕获值的缓冲区
uint32_t tim_ic_val[2] = {0};                // 最终计算得到的输入捕获值
static const float unit_time = 1000000.0f;   // 单位时间 1s
uint8_t nhx_flag[2] = {0};                   // 频率超限标志
uint8_t frequency_flag[2] = {0};             // 判断频率正负标志位
void tim_ic_proc()
{
    uint32_t current_time = HAL_GetTick();
    uint32_t tim_ic_temp[2] = {0};           // 临时存储输入捕获计算的中间值
    int32_t frequency_temp[2] = {0};        // 临时存储的频率值

    /* 计算缓冲区捕获值的总和 */
    for (uint8_t i = 0; i < 64; i++) {
        tim_ic_temp[0] += tim_ic_buffer[0][i];
        tim_ic_temp[1] += tim_ic_buffer[1][i];
    }

    /* 计算平均值 */
    tim_ic_temp[0] /= 64;
    tim_ic_temp[1] /= 64;

    /* 计算频率值，单位为 Hz */
    frequency_temp[0] = (int32_t)(unit_time / (float)tim_ic_temp[0]);
    frequency_temp[1] = (int32_t)(unit_time / (float)tim_ic_temp[1]);

    /* 频率校准 */
    frequency_temp[0] += param_arrays[2];
    frequency_temp[1] += param_arrays[2];

    /* 检查频率是否为负数 */
    if (frequency_temp[0] < 0) {
        frequency_flag[0] = 0;
    } else {
        tim_ic_val[0] = (uint32_t)frequency_temp[0];
        frequency_flag[0] = 1;
    }
    if (frequency_temp[1] < 0) {
        frequency_flag[1] = 0;
    } else {
        tim_ic_val[1] = (uint32_t)frequency_temp[1];
        frequency_flag[1] = 1;
    }


    /* 将计算得到的频率值限制在 400 到 20000 之间 */
    limit_filter(&tim_ic_val[0], 1, 400, 20000);
    limit_filter(&tim_ic_val[1], 1, 400, 20000);

    /* 频率突变检测 */
    add_data_to_buffer(&buffer_a, tim_ic_val[0], current_time);
    check_frequency_sudden_change(&recd_arrays[0], &buffer_a, 0);

    add_data_to_buffer(&buffer_b, tim_ic_val[1], current_time);
    check_frequency_sudden_change(&recd_arrays[1], &buffer_b, 1);

    /* 频率超限 */
    for (uint8_t i = 0; i < 2; i++) {
        if (tim_ic_val[i] < param_arrays[1]) {
            nhx_flag[i] = 1;
        } else if (nhx_flag[i] == 1) {
            nhx_flag[i] = 0;
            recd_arrays[3-i]++;
        }
    }
}
