#ifndef RTC_APP_H
#define RTC_APP_H

#include "bsp_system.h"

#ifdef __cplusplus
extern "C" {
#endif

void rtc_proc(void);

#ifdef __cplusplus
}
#endif

#endif /* RTC_APP_H */
