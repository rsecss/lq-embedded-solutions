#include "usart_app.h"

/***************************用于调试打印确定出现的行号（可移植）************************/
// 默认调试串口
#define DEBUG_UART_HANDLE (&huart1)

// 定义调试等级
#define DEBUG_LEVEL_NONE    0  // 不输出任何信息
#define DEBUG_LEVEL_ERROR   1  // 只输出错误信息
#define DEBUG_LEVEL_WARNING 2  // 输出警告及以上信息
#define DEBUG_LEVEL_INFO    3  // 输出信息及以上信息
#define DEBUG_LEVEL_DEBUG   4  // 输出所有调试信息

// 当前调试等级
int debug_level = DEBUG_LEVEL_DEBUG;

// 获取当前文件名（支持Windows和Unix路径分隔符）
#define _FILENAME (strrchr(__FILE__, '\\') ? strrchr(__FILE__, '\\') + 1 : __FILE__)
#define FILENAME (strrchr(_FILENAME, '/') ? strrchr(_FILENAME, '/') + 1 : _FILENAME)

char *get_timestamp()
{
    static char timestamp[16];
    snprintf(timestamp, sizeof(timestamp), "%lu", uwTick);
    return timestamp;
}

// 核心打印函数
int my_printf(UART_HandleTypeDef *huart, const char *format, ...)
{
    char buffer[512];       // 定义缓冲区，用于存储格式化后的字符串
    va_list args;           // 定义参数列表
    va_start(args, format); // 初始化参数列表
    vsnprintf(buffer, sizeof(buffer), format, args); // 格式化字符串
    va_end(args);           // 结束参数列表

    // 发送缓冲区中的数据到指定串口
    HAL_UART_Transmit(huart, (uint8_t *)buffer, strlen(buffer), 0xFFFF);
    return strlen(buffer);  // 返回发送的数据长度
}

#define ANSI_COLOR_RESET   "\033[0m"
#define ANSI_COLOR_RED     "\033[31m"
#define ANSI_COLOR_YELLOW  "\033[33m"
#define ANSI_COLOR_GREEN   "\033[32m"
#define ANSI_COLOR_BLUE    "\033[34m"
#define ANSI_COLOR_CYAN    "\033[36m"

// 控制是否启用颜色输出
#define ENABLE_COLOR_OUTPUT 0

#if ENABLE_COLOR_OUTPUT
    #define COLOR(color_code) color_code
    #define COLOR_RESET ANSI_COLOR_RESET
#else
    #define COLOR(color_code) ""
    #define COLOR_RESET ""
#endif

#define debug_printf_color(level, color, format, ...)                           \
    do {                                                                        \
        if (level <= debug_level) {                                             \
            my_printf(DEBUG_UART_HANDLE, COLOR(color) "[%s][%s:%d] " format COLOR_RESET, \
                    get_timestamp(), FILENAME, __LINE__, ##__VA_ARGS__);      \
        }                                                                       \
    } while (0)

#define debug_error(format, ...)   debug_printf_color(DEBUG_LEVEL_ERROR, ANSI_COLOR_RED, format "\r\n", ##__VA_ARGS__)
#define debug_warning(format, ...) debug_printf_color(DEBUG_LEVEL_WARNING, ANSI_COLOR_YELLOW, format "\r\n", ##__VA_ARGS__)
#define debug_info(format, ...)    debug_printf_color(DEBUG_LEVEL_INFO, ANSI_COLOR_GREEN, format "\r\n", ##__VA_ARGS__)
#define debug_debug(format, ...)   debug_printf_color(DEBUG_LEVEL_DEBUG, ANSI_COLOR_CYAN, format "\r\n", ##__VA_ARGS__)
/*******************************************************************************/

/**
 * @brief       中断回调函数
 * 
 * @param       huart1 uart1句柄
 * @retval      无 
 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART1)
    {
        uart_rx_ticks = uwTick;             // 记录接收到数据的时间
        uart_rx_index++;                    // 指针往下偏移
        HAL_UART_Receive_IT(&huart1, &uart_rx_buffer[uart_rx_index], 1);    // 使能接收中断
    }
}

#define MAX_COORDINATE_COUNT 100
uint16_t coordinate_array[MAX_COORDINATE_COUNT][2] = {0};   // 坐标数组
uint16_t coordinate_count = 0;             // 坐标数量
uint8_t scene_id = 1;                      // 场景ID
static const char *status_str[] = {"Idle", "Busy", "Wait"};

/**
 * @brief   将坐标添加到数组中
 * 
 * @param   x: x坐标
 * @param   y: y坐标
 * @retval  0: 失败
 *          1: 成功
 */
uint8_t add_coordinate(uint16_t x, uint16_t y)
{   
    /* 遍历数组 */
    for (int32_t i = 0; i < coordinate_count; i++)
    {
        /* 如果坐标已经存在，则返回失败 */
        if (coordinate_array[i][0] == x && coordinate_array[i][1] == y)
        {
            return 0;
        }

        /* 如果坐标数组已满，则返回失败 */
        if (coordinate_count >= MAX_COORDINATE_COUNT)
        {
            return 0;
        }
    }

    /* 将坐标添加到数组中 */
    coordinate_array[coordinate_count][0] = x;
    coordinate_array[coordinate_count][1] = y;
    coordinate_count++;

    return 1;
}
/**
 * @brief   删除坐标
 * 
 * @param   x x坐标
 * @param   y y坐标
 * @return  uint8_t  删除成功返回 1，否则返回 0
 */
uint8_t remove_coordinate(uint16_t x, uint16_t y)
{
    for (int32_t i = 0; i < coordinate_count; i++)
    {
        if (coordinate_array[i][0] == x && coordinate_array[i][1] == y)
        {
            for (int32_t j = i; j < coordinate_count - 1; j++)
            {
                coordinate_array[j][0] = coordinate_array[j + 1][0];
                coordinate_array[j][1] = coordinate_array[j + 1][1];
            }
            coordinate_count--;

            return 1;
        }
    }
    return 0;
}

/**
 * @brief   打印坐标
 * 
 * @param   无
 * @retval  无
 */
void print_coordinate()
{
    for (int32_t i = 0; i < coordinate_count; i++)
    {
        debug_debug("(%d,%d)\n", coordinate_array[i][0], coordinate_array[i][1]);
    }
}

/**
 * @brief   解析坐标
 * 
 * @param   command 命令字符串
 * @retval  无
 */
void anlyse_coordinate(char *command)
{

    uint16_t x = 0;
    uint16_t y = 0;

    if (strstr((const char *)command, "(") != NULL && strstr((const char *)command, ")") != NULL)
    {
        /* 获取两个括号之间字符串的长度 */
        uint16_t length = strstr((const char *)command, ")") - strstr((const char *)command, "(") - 1;

        /* 分配内存并拷贝字符串 */
        char *data = (char *)malloc(length + 1);
        data[length] = '\0';
        strncpy(data, strstr((const char *)command, "(") + 1, length);
        char *token = strtok(data, ",");
        
        /* 定义存储数组 */
        uint16_t coordinates[MAX_COORDINATE_COUNT * 2] = {0};

        /* 分割字符串 */
        uint8_t index = 0;
        while (token != NULL && index < MAX_COORDINATE_COUNT * 2)
        {
            coordinates[index] = atoi(token);
            token = strtok(NULL, ",");
            index++;
        }
        if (index % 2 == 0)
        {
            for (int32_t i = 0; i < index; i += 2)
            {
                if (coordinates[i] < 999 && coordinates[i + 1] < 999)
                {
                    if (add_coordinate(coordinates[i], coordinates[i + 1]) == 0)
                    {
                        debug_debug("Error\n");
                    }
                }
                else
                {
                    debug_debug("Error\n");
                }
            }
            debug_debug("Go it\n");
        }
        else
        {
            debug_debug("Error\n");
        }
        free(data);
    }
    else if (sscanf((const char *)command, "{%hu,%hu}", &x, &y) == 2)
    {
        if (remove_coordinate(x, y) == 1)
        {
            debug_debug("Go it\n");
        }
        else
        {
            debug_debug("Nonexistent\n");
        }
    }
    else if (sscanf((const char *)command, "[%hhu]", &scene_id) == 1)
    {
        if (device_state == Busy)
        {
            switch(scene_id)
            {
                case 1 :
                    pwm_set_frequency(1000, 16); // 设置 A 频率为 1000Hz
                    pwm_set_frequency(1000, 17); // 设置 B 频率为 1000Hz
                    printf("Go it\n");
                    break;
                case 2 :
                    pwm_set_frequency(4000, 16); // 设置 A 频率为 4000Hz
                    pwm_set_frequency(1000, 17);    // 设置 B 频率为 1000Hz
                    printf("Go it\n");
                    break;
                case 3 :
                    pwm_set_frequency(1000, 16); // 设置 A 频率为 1000Hz
                    pwm_set_frequency(4000, 17); // 设置 B 频率为 4000Hz
                    printf("Go it\n");
                    break;
                case 4 :
                    pwm_set_frequency(4000, 16); // 设置 A 频率为 4000Hz
                    pwm_set_frequency(4000, 17); // 设置 B 频率为 4000Hz
                    printf("Go it\n");
                    break;
            }
        }
        else
        {
            debug_debug("Devive offline\n");
        }
        
    }
    else if (strcmp((const char *)command, "?") == 0)
    {
        debug_debug("%s\n", status_str[device_state]);
    }
    else if (strcmp((const char *)command, "#") == 0)
    {
        debug_debug("(%d,%d)\n", current_pos_x, current_pos_y);
    }
    else
    {
        debug_debug("Error\n");
    }
}


/**
 * @brief       处理 USART 接收缓冲区中的数据
 * 
 * @note        如果在 100ms 内没有接收到新的数据，将清空缓冲区
 * @param       无
 * @retval      无
 */
void uart_proc()
{
    if (uart_rx_index == 0)
        return;   // 如果接收索引为 0，说明没有数据需要处理，直接返回
    
    if (HAL_GetTick() - uart_rx_ticks > 100)
    {
        anlyse_coordinate((char *)uart_rx_buffer);
        if (strncmp((const char *)uart_rx_buffer, "print_wp", 8) == 0)
        {
            print_coordinate();
        }

        memset(uart_rx_buffer, 0, uart_rx_index);   // 清空缓冲区
        uart_rx_index = 0;                          // 重置索引
        huart1.pRxBuffPtr = uart_rx_buffer;         // 将缓存区指针重置成初始位置
    }
}


uint16_t current_target_index = 0;
uint32_t last_time = 0;
uint32_t time_ms = 0;
uint8_t first_run = 1;
float pos_x = 0.0f;
float pos_y = 0.0f;
/**
 * @brief   上报系统信息到上位机（测试）
 * 
 * @note    定期发送当前状态、位置、速度等信息
 * @param   无
 * @retval  无
 */
void report_system_info(void)
{
    static uint32_t last_report_time = 0;
    uint32_t current_time = HAL_GetTick();
    
    // 每100ms上报一次信息
    if(current_time - last_report_time >= 100)
    {
        last_report_time = current_time;
        
        char buffer[64];
        
        // 上报状态信息
        switch(device_state)
        {
            case Idle:
                printf("$STATUS,IDLE\n");
                break;
            case Busy:
                printf("$STATUS,BUSY\n");
                break;
            case Wait:
                printf("$STATUS,WAIT\n");
                break;
        }
        
        // 上报位置信息
        sprintf(buffer, "$POS,%d,%d\n", current_pos_x, current_pos_y);
        printf("%s", buffer);
        
        // 上报目标点信息
        sprintf(buffer, "$TARGET,%d,%d\n", target_pos_x, target_pos_y);
        printf("%s", buffer);
        
        // 上报速度信息
        sprintf(buffer, "$SPEED,%.2f\n", speed);
        printf("%s", buffer);
        
        // 上报总距离和运行时间
        sprintf(buffer, "$DIST,%.2f\n", total_distance);
        printf("%s", buffer);
        sprintf(buffer, "$TIME,%lu\n", (uint32_t)total_time);
        printf("%s", buffer);
    }
}

void motion_control_proc(void)
{
    if(device_state != Busy) return;

    report_system_info();
    
    if(first_run)
    {
        pos_x = (float)current_pos_x;
        pos_y = (float)current_pos_y;
        last_time = uwTick;
        first_run = 0;
    }

    float dt = (float)(uwTick - last_time) / 1000.0f;

    time_ms += uwTick - last_time;
    total_time = time_ms / 1000;

    last_time = uwTick;
    
    float target_x = (float)coordinate_array[current_target_index][0];
    float target_y = (float)coordinate_array[current_target_index][1];

    target_pos_x = (uint16_t)target_x;
    target_pos_y = (uint16_t)target_y;

    remain_number = coordinate_count - current_target_index;

    float dx = target_x - pos_x;
    float dy = target_y - pos_y;
    float distance = sqrt(dx * dx + dy * dy);

    if(distance <= 5.0f)
    {
        pos_x = target_x;
        pos_y = target_y;
        current_pos_x = (uint16_t)pos_x;
        current_pos_y = (uint16_t)pos_y;

        current_target_index++;

        if(current_target_index >= coordinate_count)
        {
            device_state = Idle;
            target_pos_x = current_pos_x;
            target_pos_y = current_pos_y;
            first_run = 1;
            return;
        }

        target_x = (float)coordinate_array[current_target_index][0];
        target_y = (float)coordinate_array[current_target_index][1];

        target_pos_x = (uint16_t)target_x;
        target_pos_y = (uint16_t)target_y;

        dx = target_x - pos_x;
        dy = target_y - pos_y;
        distance = sqrt(dx * dx + dy * dy);
    }

    if(distance > 0)
    {
        float unit_x = dx / distance;
        float unit_y = dy / distance;

        float step_distance = speed * dt;

        if(step_distance >= distance)
        {
            total_distance += distance;
            pos_x = target_x;
            pos_y = target_y;
        }
        else
        {
            total_distance += step_distance;
            pos_x += unit_x * step_distance;
            pos_y += unit_y * step_distance;
        }

        current_pos_x = (uint16_t)pos_x;
        current_pos_y = (uint16_t)pos_y;
    }
}
