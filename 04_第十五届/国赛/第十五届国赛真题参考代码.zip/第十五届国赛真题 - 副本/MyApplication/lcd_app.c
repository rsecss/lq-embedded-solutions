#include "lcd_app.h"

/* 底层 */
/**
 * @brief       在 lcd 指定行显示格式化后的字符串
 * @param       line 要显示字符串的 LCD 行号
 * @param       format 格式化字符串，后跟要格式化的参数
 * @param       ...
 * @retval      无
 * @note        该函数接受一个行号和一个格式化字符串（类似于 printf），格式化字符串后，将其显示在 LCD 的指定行上。
 * @code
 * lcd_sprintf(0, "Temperature: %d", temperature);
 * @endcode
 */
static void lcd_sprintf(uint8_t line, char *format, ...)
{
    char string[21] = {0};
    va_list arg;
    va_start(arg, format);
    vsprintf(string, format, arg);
    va_end(arg);
    LCD_DisplayStringLine(line, (u8 *)string);
}

uint8_t lcd_display_mode = 0;
device_status_t device_state = Idle;
uint16_t current_pos_x = 0;
uint16_t current_pos_y = 0;
uint16_t target_pos_x = 0;
uint16_t target_pos_y = 0;
float speed = 0.0f;
uint16_t remain_number = 0;
float para_r = 1.0f;
uint8_t para_b = 10;
float total_distance = 0.0f;
uint32_t total_time = 0;

static const char *status_str[] = {"Idle", "Busy", "Wait"};

/**
 * @brief       lcd 测试
 * @param       无
 * @retval      无
 */
void lcd_proc()
{
    switch (lcd_display_mode)
    {
        case 0:
            lcd_sprintf(Line1, "        PARA");
            lcd_sprintf(Line3, "     ST=%s", status_str[device_state]);
            lcd_sprintf(Line4, "     CP=%d,%d", current_pos_x, current_pos_y);
            if (device_state == Idle)
            {
                lcd_sprintf(Line5, "     TP=NF     ");
                lcd_sprintf(Line7, "     RN=NF     ");
            }
            else
            {
                lcd_sprintf(Line5, "     TP=%d,%d     ",target_pos_x, target_pos_y);
                lcd_sprintf(Line7, "     RN=%d    ", remain_number);
            }
            if (device_state == Busy)
            {
                lcd_sprintf(Line6, "     SE=%.1f     ", speed);
            }
            else
            {
                lcd_sprintf(Line6, "     SE=0.0     ");
            }
            break;
        case 1:
            lcd_sprintf(Line1, "        PARA");
            lcd_sprintf(Line3, "     R=%.1f     ", para_r);
            lcd_sprintf(Line4, "     B=%d     ", para_b);
            lcd_sprintf(Line5, "              ");
            lcd_sprintf(Line6, "              ");
            lcd_sprintf(Line7, "              ");
            break;
        case 2:
            lcd_sprintf(Line1, "        RECD");
            lcd_sprintf(Line3, "     TS=%.1f    ", total_distance);
            lcd_sprintf(Line4, "     TT=%d    ", total_time);
            break;
        default:
            break;
    }
}
