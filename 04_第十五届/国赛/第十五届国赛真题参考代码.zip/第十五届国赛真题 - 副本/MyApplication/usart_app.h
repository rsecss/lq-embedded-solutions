#ifndef USART_APP_H
#define USART_APP_H

#include "bsp_system.h"

#ifdef __cplusplus
extern "C" {
#endif

void uart_proc(void);
void motion_control_proc(void);

#ifdef __cplusplus
}
#endif

#endif /* USART_APP_H */
