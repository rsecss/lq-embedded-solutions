#include "key_app.h"

static uint8_t key_val = 0;        // 当前按键状态
static uint8_t key_old = 0;        // 上一次按键状态
static uint8_t key_down = 0;       // 按键按下标志
static uint8_t key_up = 0;         // 按键松开标志

/* 底层 */
/**
 * @brief           读取按键状态
 * 
 * @param           无
 * @return          uint8_t: 返回按键编号，0 表示无按键按下，1~4 表示相应按键编号
 */
static uint8_t key_read()
{
    uint8_t temp = 0;

    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_0) == GPIO_PIN_RESET)
        temp = 1;           // 如果引脚状态为 RESET，按键一按下
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_1) == GPIO_PIN_RESET)
        temp = 2;           // 如果引脚状态为 RESET，按键二按下
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_2) == GPIO_PIN_RESET)
        temp = 3;           //如果引脚状态为 RESET，按键三按下
    if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == GPIO_PIN_RESET)
        temp = 4;           // 如果引脚状态为 RESET，按键四按下
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_2) == GPIO_PIN_RESET && HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_2) == GPIO_PIN_RESET)
        temp = 5;

    return temp;
}

uint8_t para_flag = 0;
uint32_t key_tick = 0;

/* 逻辑层 */
/**
 * @brief       按键控制处理函数
 * @details     处理按键按下事件和状态转换
 *              注意：para_r 参数曾存在浮点数精度问题，
 *              会出现数值稍微超过 2.0f 时会重置为 1.0f，
 *              但是不会显示 2.0f，而是直接显示 1.0f。
 *              该问题在当前版本已优化。
 * 
 * @param       无
 * @return      无
 */
void key_proc()
{
    key_val = key_read();
    /* 计算按下的按键（当前按下状态与前一状态异或，并与当前状态相与）*/
    key_down = key_val & (key_val ^ key_old);
    /* 计算松开的按键（当前松开状态与前一状态异或，并与当前状态相与）*/
    key_up = ~key_val & (key_val ^ key_old);
    key_old = key_val;

    switch (key_down)
    {
        case 1:
            if (device_state == Idle)
            {
                if (coordinate_count > 0)
                {
                    device_state = Busy;
                    current_pos_x = coordinate_array[0][0];  // 设置目标点为第一个坐标点 x
                    current_pos_y = coordinate_array[0][1];  // 设置目标点为第一个坐标点 y
                }
            }
            else if (device_state == Busy)
            {
                device_state = Wait;
            }
            else if (device_state == Wait)
            {
                device_state = Busy;
            }
            break;
        case 2:
            lcd_display_mode = (lcd_display_mode + 1) % 3;
            break;
        case 3:
        lcd_display_mode = (lcd_display_mode + 1) % 3;
            
            if (lcd_display_mode == 1)
            {
                para_flag = !para_flag;
            }
            break;
        case 4:
            if (lcd_display_mode == 1)
            {
                if (para_flag == 0)
                {
                    if (para_r >= 2.0f)
                    {
                        para_r = 1.0f;
                    }
                    else
                    {
                        para_r += 0.1f;
                        if (para_r > 2.0f)
                        {
                            para_r = 2.0f;
                        }
                    }
                }
                else
                {
                    para_b += 10;
                    if (para_b > 100)
                    {
                        para_b = 10;
                    }
                }
            }
            break;
        case 5:
                key_tick = uwTick;
            break;
    }

    if (key_up == 5 && device_state == Idle && uwTick - key_tick > 2000)
    {
        total_distance = total_time = 0;
    }
}
