#include "lcd_app.h"

/* 底层 */
/**
 * @brief       在 LCD 指定行显示格式化后的字符串
 * @param       line 要显示字符串的 LCD 行号
 * @param       format 格式化字符串，后跟要格式化的参数
 * @param       ...
 * @retval      无
 * @note        该函数接受一个行号和一个格式化字符串（类似于 printf），格式化字符串后，将其显示在 LCD 的指定行上。
 * @code
 * lcd_sprintf(0, "Temperature: %d", temperature);
 * @endcode
 */
static void lcd_sprintf(uint8_t line, char *format, ...)
{
    char string[21] = {0};
    va_list arg;
    va_start(arg, format);
    vsprintf(string, format, arg);
    va_end(arg);
    LCD_DisplayStringLine(line, (u8 *)string);
}

/* 逻辑层 */
uint8_t lcd_display_mode = 0;        // 显示模式 0: 数据，1: 参数 2: 统计
uint8_t data_display_mode = 0;       // 数据显示模式 0: 频率，1: 周期 
int32_t param_arrays[3] = {1000,5000,0}; // 参数数组 0-PD 1-PH 2-PX
uint8_t recd_arrays[4] = {0};        // 数据统计数组 0-NDA 1-NDB 2-NHA 3-NHB
/**
 * @brief       lcd 测试程序
 * @param       无
 * @retval      无
 */
void lcd_proc()
{
    uint16_t temp[2] = {0};     // 临时存储周期

    switch (lcd_display_mode) {
        case 0:
            if (data_display_mode == 0) {
                lcd_sprintf(Line1, "        DATA");
                if (frequency_flag[1] == 1) {
                    if (tim_ic_val[1] > 1000) {
                        lcd_sprintf(Line3, "     A=%.2fKHz    ",(float)(tim_ic_val[1] / 1000.0f));
                    } else {
                        lcd_sprintf(Line3, "     A=%dHz    ",tim_ic_val[1]);
                    }
                } else {
                    lcd_sprintf(Line3, "     A=NULL    ");
                }

                if (frequency_flag[0] == 1) {
                    if (tim_ic_val[0] > 1000) {
                        lcd_sprintf(Line4, "     B=%.2fKHz    ",(float)(tim_ic_val[0] / 1000.0f));
                    } else {
                        lcd_sprintf(Line4, "     B=%dHz    ",tim_ic_val[0]);
                    }
                } else {
                    lcd_sprintf(Line4, "     B=NULL    ");
                }
            } else {
                temp[0] = (int32_t)(1000000.0f / (float)tim_ic_val[1]);
                temp[1] = (int32_t)(1000000.0f / (float)tim_ic_val[0]);

                if (frequency_flag[1] == 1) {
                    if (temp[0] > 1000) {
                        lcd_sprintf(Line3, "     A=%.2fmS    ",(float)(temp[0] / 1000.0f));
                    } else {
                        lcd_sprintf(Line3, "     A=%duS    ",temp[0]);
                    } 
                } else {
                    lcd_sprintf(Line3, "     A=NULL    ");
                }
                
                if (frequency_flag[0] == 1) {
                    if (temp[1] > 1000) {
                        lcd_sprintf(Line4, "     B=%.2fmS    ",(float)(temp[1] / 1000.0f));
                    } else if (temp[1] > 0) {
                        lcd_sprintf(Line4, "     B=%duS    ",temp[1]);
                    }
                } else {
                    lcd_sprintf(Line4, "     B=NULL    ");
                }
            }
            break;
        case 1:
            lcd_sprintf(Line1, "        PARA");
            lcd_sprintf(Line3, "     PD=%dHz    ",param_arrays[0]);
            lcd_sprintf(Line4, "     PH=%dHz    ",param_arrays[1]);
            lcd_sprintf(Line5, "     PX=%dHz    ",param_arrays[2]);
            break;
        case 2:
            lcd_sprintf(Line1, "        RECD");
            lcd_sprintf(Line3, "     NDA=%d    ",recd_arrays[0]);
            lcd_sprintf(Line4, "     NDB=%d    ",recd_arrays[1]);
            lcd_sprintf(Line5, "     NHA=%d    ",recd_arrays[2]);
            lcd_sprintf(Line6, "     NHB=%d    ",recd_arrays[3]);
            break;
        default:
            break;
    }
}
