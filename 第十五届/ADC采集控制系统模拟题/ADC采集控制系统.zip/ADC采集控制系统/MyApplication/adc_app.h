#ifndef ADC_APP_H
#define ADC_APP_H

#include "bsp_system.h"

#ifdef __cplusplus
extern "C" {
#endif

void adc_proc(void);        /* ADC 调度函数 */

#ifdef __cplusplus
}
#endif

#endif /* ADC_APP_H */
