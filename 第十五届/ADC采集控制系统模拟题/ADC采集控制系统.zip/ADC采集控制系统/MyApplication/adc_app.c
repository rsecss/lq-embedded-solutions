#include "adc_app.h"

static const uint16_t WINDOW_SIZE_MS = 3000;  // 动态窗口的大小为 3 秒
static const uint8_t BUFFER_SIZE = 30;      // 缓冲区大小，假设每 100 毫秒采集一次数据

typedef struct {
    uint32_t timestamp;         // 采集时的时间戳
    uint32_t collect_adc_value; // 采集到的 ADC
}adc_data_t;

static adc_data_t adc_data_buffer[BUFFER_SIZE] = {0};
static int32_t buffer_start = 0;                // 缓冲区的起始位置
static int32_t buffer_end = 0;                  // 缓冲区的结束位置
static uint8_t sudden_detected_change_flag = 0; // 标志位，表示当前窗口内是否检测到突变

uint32_t difference = 0;                        // 差值

uint32_t adc_dma_buffer[2][30] = {0};
float adc_value[2] = {0.0};

/**
 * @brief       添加新数据到缓冲区并管理窗口数据
 * 
 * @param       adc 采集到的 ADC
 * @param       current_time 当前时间戳
 * @param       adc_data_buffer 缓冲区数组
 */
void add_adc_data(uint16_t adc, uint32_t current_time, adc_data_t *adc_data_buffer)
{
    adc_data_buffer[buffer_end].timestamp = current_time;
    adc_data_buffer[buffer_end].collect_adc_value = adc;
    buffer_end = (buffer_end + 1) % BUFFER_SIZE;

    /* 判断缓冲区是否满了，调整 buffer_start，使得窗口始终保持在 3s 内 */
    if (buffer_end == buffer_start) {
        buffer_start = (buffer_start + 1) % BUFFER_SIZE;
    }

    /* 移除窗口外的数据 */
    while (current_time - adc_data_buffer[buffer_start].timestamp > WINDOW_SIZE_MS) {
        buffer_start = (buffer_start + 1) % BUFFER_SIZE;
    }
}

/**
 * @brief       检查窗口内是否有突变
 * 
 * @param       sudden_change_count 突变计数器
 * @param       adc_data_buffer 缓冲区数组
 * @retval      无 
 */
void adc_check_sudden_change(uint16_t *sudden_change_count, adc_data_t *adc_data_buffer)
{
    uint32_t vmax = adc_data_buffer[buffer_start].collect_adc_value;
    uint32_t vmin = adc_data_buffer[buffer_start].collect_adc_value;
    uint8_t adc_data_buffer_index = buffer_start;

    /* 遍历窗口内的数据，计算差值 */
    while (adc_data_buffer_index != buffer_end) {
        if (adc_data_buffer[adc_data_buffer_index].collect_adc_value > vmax) {
            vmax = adc_data_buffer[adc_data_buffer_index].collect_adc_value;
        }
        if (adc_data_buffer[adc_data_buffer_index].collect_adc_value < vmin) {
            vmin = adc_data_buffer[adc_data_buffer_index].collect_adc_value;
        }

        adc_data_buffer_index = (adc_data_buffer_index + 1) % BUFFER_SIZE;
    }

    difference = vmax - vmin;      // 计算差值（外部声明）

    /* 如果差值小于 pd_value，则认为有突变，否则认为没有 */
    if (difference < pd_value) {
        sudden_detected_change_flag = 1;
    } else {
        sudden_detected_change_flag = 0;
        (*sudden_change_count)++;
    }
}

/**
 * @brief       ADC 转换调度函数
 * 
 * @param       无
 * @retval      无
 */
void adc_proc()
{
    uint32_t current_time = HAL_GetTick();  // 获取当前时间戳

    adc_value[0] = 0.0;
    adc_value[1] = 0.0;

    for (uint8_t i = 0; i < 30; i++) {
        adc_value[0] += (float)adc_dma_buffer[0][i];
        adc_value[1] += (float)adc_dma_buffer[1][i];
    }

    adc_value[0] = adc_value[0] / 30;
    adc_value[1] = adc_value[1] / 30;

    /* 模拟实现窗口数据管理 */
    add_adc_data((uint16_t)adc_value[0], current_time, adc_data_buffer);        // 添加新数据到缓冲区并管理窗口数据
    adc_check_sudden_change(&vd_value, adc_data_buffer);                        // 检查窗口内是否有突变

    /* 模拟实现上升沿检测 */
    if ((int)adc_value[1] < ph_value) {
        vh_flag = 1;
    } else if (vh_flag == 1) {
        vh_flag = 0;
        vh_value++;
    }
}
