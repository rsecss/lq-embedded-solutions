#ifndef SYSTEM_H
#define SYSTEM_H

#include "bsp_system.h"

#ifdef __cplusplus
extern "C" {
#endif

void system_init(void);

#ifdef __cplusplus
}
#endif

#endif /* SYSTEM_H */
