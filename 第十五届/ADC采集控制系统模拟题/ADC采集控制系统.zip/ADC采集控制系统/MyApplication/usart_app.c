#include "usart_app.h"

/**
 * @brief       中断回调函数
 * 
 * @param       huart1: uart1句柄
 * @retval      无 
 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART1) {
        uart_rx_ticks = HAL_GetTick();      /* 记录接收到数据的时间 */
        uart_rx_index++;                    /* 指针往下偏移 */
        HAL_UART_Receive_IT(&huart1, &uart_rx_buffer[uart_rx_index], 1);                /* 使能接收中断 */
    }
}

/**
 * @brief       处理 USART 接收缓冲区中的数据
 *              如果在 100ms 内没有接收到新的数据，将清空缓冲区
 * @param       无
 * @retval      无
 */
void uart_proc()
{
    if (uart_rx_index == 0)
        return;   /* 如果接收索引为 0，说明没有数据需要处理，直接返回 */

    uint16_t value = 0;
    uint16_t *p = NULL;

    if (sscanf((const char *)uart_rx_buffer, "$PD(%hu)", &value) == 1) {
        p = &pd_value;
    } else if (sscanf((const char *)uart_rx_buffer, "$PH(%hu)", &value) == 1) {
        p = &ph_value;
    } else if (strcmp((const char *)uart_rx_buffer, "#VH") == 0) {
        printf("VH:%d\n", vh_value);
    } else if (strcmp((const char *)uart_rx_buffer, "#VD") == 0) {
        printf("VD:%d\n", vd_value);
    }

    if (p != NULL) {
        if (*p < 4096) {
            *p = value;
        }
    }

    if (HAL_GetTick() - uart_rx_ticks > 100) {
        printf("uart data: %s\n", uart_rx_buffer);
        memset(uart_rx_buffer, 0, uart_rx_index);   /* 清空缓冲区 */
        uart_rx_index = 0;                          /* 重置索引 */
        huart1.pRxBuffPtr = uart_rx_buffer;         /* 将缓存区指针重置成初始位置 */
    }
}
