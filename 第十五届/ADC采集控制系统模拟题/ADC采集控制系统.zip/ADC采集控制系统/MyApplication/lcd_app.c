#include "lcd_app.h"

/* 底层 */
/**
 * @brief       在 lcd 指定行显示格式化后的字符串
 * @param       line 要显示字符串的 LCD 行号
 * @param       format 格式化字符串，后跟要格式化的参数
 * @param       ...
 * @retval      无
 * @note        该函数接受一个行号和一个格式化字符串（类似于 printf），格式化字符串后，将其显示在 LCD 的指定行上。
 * @code
 * lcd_sprintf(0, "Temperature: %d", temperature);
 * @endcode
 */
static void lcd_sprintf(uint8_t line, char *format, ...)
{
    char string[21] = {0};
    va_list arg;
    va_start(arg, format);
    vsprintf(string, format, arg);
    va_end(arg);
    LCD_DisplayStringLine(line, (uint8_t *)string);
}

uint8_t lcd_display_mode = 0;       // lcd 显示模式
uint16_t pd_value = 1000;           // PD 值
uint16_t ph_value = 2000;           // PH 值
uint16_t vh_value = 0;              // VH 值
uint16_t vd_value = 0;              // VD 值
uint8_t vh_flag = 0;                // VH 值标志
uint8_t pd_ph_flag = 0;             // pd、ph标志位

/**
 * @brief       lcd 测试程序
 * @param       无
 * @retval      无
 */
void lcd_proc()
{
    switch (lcd_display_mode) {
        case 0:
            lcd_sprintf(Line1, "        DATA");
            lcd_sprintf(Line3, "   R37=%d    ",(int)adc_value[1]);
            lcd_sprintf(Line4, "   R38=%d    ",(int)adc_value[0]);
            break;
        case 1:
            lcd_sprintf(Line1, "        PARA");
            lcd_sprintf(Line3, "    PD=%d    ",pd_value);
            lcd_sprintf(Line4, "    PH=%d    ",ph_value);
            break;
        case 2:
            lcd_sprintf(Line1, "        RECD");
            lcd_sprintf(Line3, "    VH=%d    ",vh_value);
            lcd_sprintf(Line4, "    VD=%d    ",vd_value);
            break;
        default:
            break;
    }
}
