#ifndef LED_APP_H
#define LED_APP_H

#include "bsp_system.h"

#ifdef __cplusplus
extern "C" {
#endif

void led_proc(void);

#ifdef __cplusplus
}
#endif

#endif /* LED_APP_H */
