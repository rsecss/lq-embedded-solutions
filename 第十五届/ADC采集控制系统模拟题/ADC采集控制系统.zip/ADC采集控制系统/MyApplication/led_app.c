#include "led_app.h"

// static const uint8_t LED_ON = 0xFF;     /* 0xFF 表示全亮 */
// static const uint8_t LED_OFF = 0x00;    /* 0x00 表示全灭 */
static const uint8_t LED_PIN_SHIFT = 0x08;

/* 底层 */
/**
 * @brief       LED 显示函数
 * @param       led: 要控制 LED 的位置，取值范围：0x00~0xFF
 * @retval      无
 */
static void led_display(uint8_t led)
{
    /* 关闭所有的 LED */
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10 |
                    GPIO_PIN_11 | GPIO_PIN_12 | GPIO_PIN_13 |
                    GPIO_PIN_14 |GPIO_PIN_15, GPIO_PIN_SET);
    // HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, GPIO_PIN_SET);
    // HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, GPIO_PIN_RESET);

    /* 根据 ucLed 的值点亮相应的灯 */
    HAL_GPIO_WritePin(GPIOC, (uint16_t)(led << LED_PIN_SHIFT), GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, GPIO_PIN_SET);
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, GPIO_PIN_RESET);
}

/* 逻辑层 */
void led_proc()
{
    uint8_t led_state = 0x00;

    // 条件1：模式0时点亮LED1
    if (lcd_display_mode == 0) {
        led_state |= 0x01;  // 第1位
    }

    // 条件2：ADC值超过阈值时点亮LED2
    if ((int)adc_value[1] > ph_value) {
        led_state |= 0x02;  // 第2位
    }

    // 条件3：差值超过阈值时点亮LED3
    if (difference > pd_value) {
        led_state |= 0x04;  // 第3位
    }

    // 统一设置LED状态
    led_display(led_state);
}
