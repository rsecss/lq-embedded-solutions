#include "lcd_app.h"

/* 底层 */
/**
 * @brief       在 lcd 指定行显示格式化后的字符串
 * @param       line 要显示字符串的 LCD 行号
 * @param       format 格式化字符串，后跟要格式化的参数
 * @param       ...
 * @retval      无
 * @note        该函数接受一个行号和一个格式化字符串（类似于 printf），格式化字符串后，将其显示在 LCD 的指定行上。
 * @code
 * lcd_sprintf(0, "Temperature: %d", temperature);
 * @endcode
 */
static void lcd_sprintf(uint8_t line, char *format, ...)
{
    char string[21] = {0};
    va_list arg;
    va_start(arg, format);
    vsprintf(string, format, arg);
    va_end(arg);
    LCD_DisplayStringLine(line, (u8 *)string);
}

uint8_t lcd_display_mode = 0;           // 显示模式
uint8_t cnbr_count = 0;                 // CNBR 计数器
uint8_t vnbr_count = 0;                 // VNBR 计数器
float parking_rates[2] = {3.5f, 2.0f};  // 停车费率
/**
 * @brief       lcd 测试
 * @param       无
 * @retval      无
 */
void lcd_proc()
{
    if (pwm_output_flag == 1)
    {
        pwm_set_frequency(2000, 17);
        pwm_set_duty(20, 17);
        printf("1\n");
    }
    else
    {
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_RESET);
    }

    if (lcd_display_mode == 0)
    {
        lcd_sprintf(Line1, "       Data    ");
        lcd_sprintf(Line3, "   CNBR:%d    ", cnbr_count);
        lcd_sprintf(Line5, "   VNBR:%d    ", vnbr_count);
        lcd_sprintf(Line7, "   IDLE:%d    ", 8 - vehicle_count);
    }
    else
    {
        lcd_sprintf(Line1, "       Para    ");
        lcd_sprintf(Line3, "   CNBR:%.2f    ", parking_rates[0]);
        lcd_sprintf(Line5, "   VNBR:%.2f    ", parking_rates[1]);
        lcd_sprintf(Line7, "                ");
    }
}
