#include "lcd_app.h"

/* 底层 */
/**
 * @brief       在 lcd 指定行显示格式化后的字符串
 * @param       line 要显示字符串的 LCD 行号
 * @param       format 格式化字符串，后跟要格式化的参数
 * @param       ...
 * @retval      无
 * @note        该函数接受一个行号和一个格式化字符串（类似于 printf），格式化字符串后，将其显示在 LCD 的指定行上。
 * @code
 * lcd_sprintf(0, "Temperature: %d", temperature);
 * @endcode
 */
static void lcd_sprintf(uint8_t line, char *format, ...)
{
    char string[21] = {0};
    va_list arg;
    va_start(arg, format);
    vsprintf(string, format, arg);
    va_end(arg);
    LCD_DisplayStringLine(line, (u8 *)string);
}

uint8_t lcd_display_mode = 0;                   // 显示模式
uint8_t password_data[3] = {'1', '2', '3'};     // 密码数据
uint8_t password_input[3] = {'@', '@', '@'};    // 输入密码
uint16_t frequency_value = 0;                   // 频率值
uint8_t duty_value = 0;                         // 占空比值

/**
 * @brief       lcd 测试
 * @param       无
 * @retval      无
 */
void lcd_proc()
{
    pwm_set_frequency(frequency_value, 2);
    pwm_set_duty(duty_value, 2);

    frequency_value = 1000 + 1000 * lcd_display_mode;
    duty_value = 50 - 40 * lcd_display_mode;

    if (lcd_display_mode == 0)
    {
        lcd_sprintf(Line1, "       PSD    ");
        lcd_sprintf(Line3, "    B1:%c    ", password_input[0]);
        lcd_sprintf(Line4, "    B2:%c    ", password_input[1]);
        lcd_sprintf(Line5, "    B3:%c    ", password_input[2]);
    }
    else
    {
        lcd_sprintf(Line1, "       STA    ");
        lcd_sprintf(Line3, "    F:%dHz    ", frequency_value);
        lcd_sprintf(Line4, "    D:%d%%    ", duty_value);
        lcd_sprintf(Line5, "              ");
    }
}
