#include "lcd_app.h"

/* 底层 */
/**
 * @brief       在 lcd 指定行显示格式化后的字符串
 * @param       line 要显示字符串的 LCD 行号
 * @param       format 格式化字符串，后跟要格式化的参数
 * @param       ...
 * @retval      无
 * @note        该函数接受一个行号和一个格式化字符串（类似于 printf），格式化字符串后，将其显示在 LCD 的指定行上。
 * @code
 * lcd_sprintf(0, "Temperature: %d", temperature);
 * @endcode
 */
static void lcd_sprintf(uint8_t line, char *format, ...)
{
    char string[21] = {0};
    va_list arg;
    va_start(arg, format);
    vsprintf(string, format, arg);
    va_end(arg);
    LCD_DisplayStringLine(line, (u8 *)string);
}

/* 逻辑层 */
uint8_t lcd_dispaly_mode = 0;        // LCD 显示模式
uint8_t pwm_output_mode = 0;         // PWM 输出模式 0：低频 1：高频
uint8_t duty_value = 0;              // PWM 输出占空比
float speed_value = 0.0f;            // 速度
uint8_t param_arrays[2] = {1, 1};    // 设置值 0-R 1-K
uint8_t set_value[2] = {1, 1};       // 设置值 0-R 1-K
uint8_t pwm_change_count = 0;        // PWM 切换次数
float speed_max[2] = {0.0f};         // 速度最大值

/**
 * @brief       lcd 测试程序
 * @param       无
 * @retval      无
 */
void lcd_proc()
{
    switch (lcd_dispaly_mode)
    {
        case 0:
            lcd_sprintf(Line1, "        DATA    ");
            lcd_sprintf(Line3, "     M=%s    ", pwm_output_mode == 0 ? "L" : "H");
            lcd_sprintf(Line4, "     P=%d%%    ", duty_value);
            lcd_sprintf(Line5, "     V=%.1f    ", speed_value);
            break;
        case 1:
            lcd_sprintf(Line1, "        PARA    ");
            lcd_sprintf(Line3, "     R=%d    ", param_arrays[0]);
            lcd_sprintf(Line4, "     K=%d    ", param_arrays[1]);
            lcd_sprintf(Line5, "                    ");
            break;
        case 2:
            lcd_sprintf(Line1, "        RECD    ");
            lcd_sprintf(Line3, "     N=%d    ", pwm_change_count);
            lcd_sprintf(Line4, "     MH=%.1f    ", speed_max[1]);
            lcd_sprintf(Line5, "     ML=%.1f    ", speed_max[0]);
            break;
    }
}
