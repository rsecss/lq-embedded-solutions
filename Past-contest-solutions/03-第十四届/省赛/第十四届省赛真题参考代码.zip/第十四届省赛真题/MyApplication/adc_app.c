#include "adc_app.h"

uint32_t adc_dma_buffer[2][50] = {0};    // DMA 缓冲区
float adc_value[2] = {0.0};              // ADC 转换值

uint32_t pwm_tick = 0;                   // PWM 更新时间戳
uint16_t frequency_value = 4000;         // PWM 频率
uint8_t led_flag = 0;                    // LED 闪烁标志

/**
 * @brief       ADC 转换调度函数
 * 
 * @param       无
 * @retval      无
 */
void adc_proc()
{
    /* 读取 ADC 转换值并转换成电压值 */
    adc_value[0] = 0.0;     // R38
    adc_value[1] = 0.0;     // R37
    
    for (uint8_t i = 0; i < 50; i++) 
    {
        adc_value[0] += (float)adc_dma_buffer[0][i];
        adc_value[1] += (float)adc_dma_buffer[1][i];
    }

    adc_value[0] = adc_value[0] / 50 * 3.3f / 4096;
    adc_value[1] = adc_value[1] / 50 * 3.3f / 4096;
    
    pwm_set_frequency(frequency_value, 2);

    /* 根据电压值设置 PWM 占空比 */
    if (duty_lock_flag == 0)
    {
        if (adc_value[1] <= 1.0f)
        {
            duty_value = 10;
        }
        else if (adc_value[1] >= 3.0f)
        {
            duty_value = 85;
        }
        else
        {
            duty_value = (85 - 10) / (3.0f - 1.0f) * (adc_value[1] - 1.0f) + 10;
        }
        pwm_set_duty(duty_value, 2);        // 硬件上改变占空比，否则只是数值上面改变了，实际没有改变，同样好比掩耳盗铃
    }

    /* 在占空比不变的情况下，设置 PWM 频率 */
    if (uwTick - pwm_tick >= 100)
    {
        if (frequency_value != (pwm_output_mode == 0 ? 4000 : 8000))
        {   
            led_flag ^= 1;             // LED 闪烁
            frequency_value += ((8000 - 4000) / 50) * (pwm_output_mode == 1 ? 1 : -1);

            pwm_set_frequency(frequency_value, 2);      // 硬件上改变频率，否则只是数值上面改变了，实际没有改变，同样好比掩耳盗铃
        }
        else
        {
            led_flag = 0;
        }
        pwm_tick = uwTick;
    }
}
