#include "key_app.h"

static uint8_t key_val = 0;        /* 当前按键状态 */
static uint8_t key_old = 0;        /* 上一次按键状态 */
static uint8_t key_down = 0;       /* 按键按下标志 */
static uint8_t key_up = 0;         /* 按键松开标志 */

/* 底层 */
/**
 * @brief           读取按键状态
 * 
 * @param           无
 * @return          uint8_t: 返回按键编号，0 表示无按键按下，1~4 表示相应按键编号
 */
static uint8_t key_read()
{
    uint8_t temp = 0;       /* 临时变量 */

    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_0) == GPIO_PIN_RESET)
        temp = 1;           /*如果引脚状态为 RESET，按键一按下 */
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_1) == GPIO_PIN_RESET)
        temp = 2;           /*如果引脚状态为 RESET，按键二按下 */
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_2) == GPIO_PIN_RESET)
        temp = 3;           /*如果引脚状态为 RESET，按键三按下 */
    if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == GPIO_PIN_RESET)
        temp = 4;           /* 如果引脚状态为 RESET，按键四按下 */

    return temp;
}

/* 逻辑层 */
uint32_t lcd_dispaly_tick = 0;      // LCD 显示时间戳
uint32_t key_tick = 0;              // 按键扫描时间戳
uint8_t set_index = 0;              // 设置索引
uint8_t duty_lock_flag = 0;         // 占空比锁定标志 0：未锁定 1：锁定
/**
 * @brief           按键控制 led 处理函数（四行代码版本）
 * @param           无
 * @retval          无
 */
void key_proc()
{
    key_val = key_read();
    /* 计算按下的按键（当前按下状态与前一状态异或，并与当前状态相与）*/
    key_down = key_val & (key_val ^ key_old);
    /* 计算松开的按键（当前松开状态与前一状态异或，并与当前状态相与）*/
    key_up = ~key_val & (key_val ^ key_old);
    key_old = key_val;

    switch (key_down)
    {
        case 1:
            lcd_dispaly_mode = (lcd_dispaly_mode + 1) % 3;
            if (lcd_dispaly_mode == 2)
            {
                set_index = 0;
                set_value[0] = param_arrays[0];
                set_value[1] = param_arrays[1];
            }
            break;
        case 2:
            if (lcd_dispaly_mode == 0)
            {
                if (uwTick - lcd_dispaly_tick > 5000 || lcd_dispaly_tick == 0)
                {
                    pwm_output_mode ^= 1;
                    lcd_dispaly_tick = uwTick;
                    speed_max[1] = speed_max[0];
                    pwm_change_count++;
                }
            }
            else if (lcd_dispaly_mode == 1)
            {
                set_index ^= 1;
            }
            break;
        case 3:
            if (lcd_dispaly_mode == 1)
            {
                param_arrays[set_index]++;
                if (param_arrays[set_index] == 11)
                {
                    param_arrays[set_index] = 1;
                }
            }
            break;
        case 4:
            key_tick = uwTick;
            break;
    }

    /* 按键四的功能 */
    if (key_up == 4)
    {
        if (uwTick - key_tick > 2000)
        {
            if (lcd_dispaly_mode == 0 && duty_lock_flag == 0)
            {
                duty_lock_flag = 1;
            }
        }
        else
        {
            if (lcd_dispaly_mode == 0 && duty_lock_flag == 1)
            {
                duty_lock_flag = 0;
            }
            else if (lcd_dispaly_mode == 1)
            {
                param_arrays[set_index]--;
                if (param_arrays[set_index] == 0)
                {
                    param_arrays[set_index] = 10;
                }
            }
            
        }
    }
    
}
