#include "scheduler.h"

typedef struct
{
    void (*task_func)(void);
    uint32_t period_ms;
    uint32_t last_run_time;
} scheduler_task_t;

static scheduler_task_t scheduler_tasks[] = {
    {key_proc, 10, 0},
    {adc_proc, 20, 0},
    {tim_proc, 50, 0},
    {rtc_proc, 10, 0},
    {led_proc, 10, 0},
    {lcd_proc, 100, 0},
    {uart_proc, 10, 0},
};

static uint8_t scheduler_task_count = 0;

/**
 * @brief  初始化时间片调度器任务数量
 * @param  无
 * @retval 无
 */
void scheduler_init(void)
{
    scheduler_task_count =
        (uint8_t)(sizeof(scheduler_tasks) / sizeof(scheduler_tasks[0]));
}

/**
 * @brief  按任务周期执行应用层调度函数
 * @param  无
 * @retval 无
 */
void scheduler_run(void)
{
    uint32_t now = HAL_GetTick();

    for (uint8_t index = 0; index < scheduler_task_count; index++)
    {
        /* 无符号减法可正确处理 HAL_GetTick() 回绕。 */
        if (now - scheduler_tasks[index].last_run_time >=
            scheduler_tasks[index].period_ms)
        {
            scheduler_tasks[index].last_run_time = now;
            scheduler_tasks[index].task_func();
        }
    }
}
