#include "adc_app.h"

uint32_t adc_dma_buffer[ADC_APP_CHANNEL_COUNT][ADC_APP_SAMPLE_COUNT] = {0};

/**
 * @brief  计算单路 ADC DMA 缓冲区的平均原始码值
 * @param  samples ADC DMA 采样缓冲区
 * @return 50 次采样的平均原始码值
 */
static uint16_t adc_average(const uint32_t *samples)
{
    uint32_t sum = 0;

    for (uint32_t index = 0; index < ADC_APP_SAMPLE_COUNT; index++)
    {
        sum += samples[index];
    }

    return (uint16_t)(sum / ADC_APP_SAMPLE_COUNT);
}

/**
 * @brief  ADC 采样与 PWM 更新调度函数
 * @param  无
 * @retval 无
 */
void adc_proc(void)
{
    /* R38 对应频率，R37 对应占空比，通道顺序与 main.c DMA 启动一致。 */
    uint16_t frequency_adc = adc_average(adc_dma_buffer[0]);
    uint16_t duty_adc = adc_average(adc_dma_buffer[1]);

    pwm_update(frequency_adc, duty_adc);
}
