#ifndef KEY_APP_H
#define KEY_APP_H

#include "bsp_system.h"

#ifdef __cplusplus
extern "C" {
#endif

void key_proc(void); /* 按键扫描与功能调度函数 */
void key_app_get_parameter_draft(pwm_parameters_t *parameters); /* 获取参数编辑草稿 */

#ifdef __cplusplus
}
#endif

#endif /* KEY_APP_H */
