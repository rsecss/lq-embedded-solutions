#ifndef LED_APP_H
#define LED_APP_H

#include "bsp_system.h"

#ifdef __cplusplus
extern "C" {
#endif

void led_proc(void); /* LED 状态刷新调度函数 */

#ifdef __cplusplus
}
#endif

#endif /* LED_APP_H */
