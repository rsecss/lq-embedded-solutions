#ifndef BSP_SYSTEM_H
#define BSP_SYSTEM_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdarg.h>
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "main.h"
#include "rtc.h"
#include "tim.h"
#include "usart.h"

/* 跨模块共享类型统一放在聚合头中，避免模块头相互包含。 */
typedef struct
{
    uint32_t duty_step_pct;
    uint32_t duty_limit_pct;
    uint32_t frequency_step_hz;
    uint32_t frequency_limit_hz;
} pwm_parameters_t;

typedef enum
{
    UI_MONITOR = 0,
    UI_STAT,
    UI_PARAM
} ui_mode_t;

typedef enum
{
    PARAM_DS = 0,
    PARAM_DR,
    PARAM_FS,
    PARAM_FR
} param_select_t;

/* 应用模块头文件聚合。 */
#include "adc_app.h"
#include "filter.h"
#include "i2c_hal.h"
#include "key_app.h"
#include "lcd.h"
#include "lcd_app.h"
#include "led_app.h"
#include "rtc_app.h"
#include "scheduler.h"
#include "tim_app.h"
#include "usart_app.h"

/* 串口模块全局变量。 */
extern uint8_t uart_rx_buffer[128];

/* ADC 模块全局变量。 */
extern uint32_t adc_dma_buffer[ADC_APP_CHANNEL_COUNT][ADC_APP_SAMPLE_COUNT];

/* TIM/PWM 模块全局变量。 */
extern uint32_t tim_ic_buffer[TIM_APP_CAPTURE_CHANNEL_COUNT]
                             [TIM_APP_CAPTURE_SAMPLE_COUNT];
extern uint32_t tim_ic_val[TIM_APP_CAPTURE_CHANNEL_COUNT];
extern pwm_parameters_t pwm_parameters;
extern uint8_t system_locked;
extern uint32_t current_freq;
extern uint32_t current_duty;

/* 异常状态与统计界面快照。 */
extern uint8_t abnormal_flag;
extern uint32_t stat_CF;
extern uint32_t stat_CD;
extern uint32_t stat_DF;
extern uint32_t stat_XF;
extern uint32_t stat_runtime;

/* LCD 界面状态。 */
extern ui_mode_t current_ui;
extern param_select_t selected_param;

/* 系统运行时长。 */
extern uint32_t runtime_seconds;

#ifdef __cplusplus
}
#endif

#endif /* BSP_SYSTEM_H */
