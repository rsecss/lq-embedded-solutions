#include "tim_app.h"

#define PWM_COUNTER_HZ 1000000UL
#define ADC_FULL_SCALE 4096UL
#define PWM_FREQUENCY_MIN_HZ 1000UL
#define PWM_DUTY_MIN_PCT 10UL

uint32_t tim_ic_buffer[TIM_APP_CAPTURE_CHANNEL_COUNT]
                       [TIM_APP_CAPTURE_SAMPLE_COUNT] = {0};
uint32_t tim_ic_val[TIM_APP_CAPTURE_CHANNEL_COUNT] = {0};

pwm_parameters_t pwm_parameters = {
    .duty_step_pct = 1,
    .duty_limit_pct = 80,
    .frequency_step_hz = 100,
    .frequency_limit_hz = 2000,
};

uint8_t system_locked = 0;
uint32_t current_freq = PWM_FREQUENCY_MIN_HZ;
uint32_t current_duty = PWM_DUTY_MIN_PCT;

uint8_t abnormal_flag = 0;
uint32_t stat_CF = 0;
uint32_t stat_CD = 0;
uint32_t stat_DF = 0;
uint32_t stat_XF = 0;
uint32_t stat_runtime = 0;

static uint8_t pwm_applied = 0;

/**
 * @brief  将 ADC 原始码映射为固定步长的输出值
 * @param  adc_sample ADC 平均原始码值
 * @param  minimum 固定下限
 * @param  maximum 参数设定上限
 * @param  step 调节步长
 * @return 映射后的阶梯值
 */
static uint32_t map_adc_to_step(uint16_t adc_sample, uint32_t minimum,
                                uint32_t maximum, uint32_t step)
{
    uint32_t span = maximum - minimum;
    uint32_t maximum_index = span / step;
    uint64_t numerator = (uint64_t)adc_sample * span;
    uint64_t denominator = (uint64_t)ADC_FULL_SCALE * step;
    uint32_t index = (uint32_t)(numerator / denominator);

    /* 先按完整调节范围求档位，再限制到最后一个完整步长。 */
    if (index > maximum_index)
    {
        index = maximum_index;
    }

    return minimum + index * step;
}

/**
 * @brief  根据两路 ADC 原始码更新 TIM17 PWM 频率和占空比
 * @param  frequency_adc R38 对应的频率调节原始码
 * @param  duty_adc R37 对应的占空比调节原始码
 * @retval 无
 */
void pwm_update(uint16_t frequency_adc, uint16_t duty_adc)
{
    uint32_t target_frequency;
    uint32_t target_duty;
    uint32_t period_ticks;
    uint32_t compare_ticks;

    if (system_locked != 0U)
    {
        return;
    }

    target_frequency = map_adc_to_step(
        frequency_adc, PWM_FREQUENCY_MIN_HZ,
        pwm_parameters.frequency_limit_hz,
        pwm_parameters.frequency_step_hz);
    target_duty = map_adc_to_step(
        duty_adc, PWM_DUTY_MIN_PCT, pwm_parameters.duty_limit_pct,
        pwm_parameters.duty_step_pct);

    if ((pwm_applied != 0U) && (target_frequency == current_freq) &&
        (target_duty == current_duty))
    {
        return;
    }

    period_ticks = PWM_COUNTER_HZ / target_frequency;
    compare_ticks = period_ticks * target_duty / 100U;

    /* 逻辑层通过 HAL 封装同步更新 ARR、CCR 和更新事件。 */
    __HAL_TIM_SET_AUTORELOAD(&htim17, period_ticks - 1U);
    __HAL_TIM_SET_COMPARE(&htim17, TIM_CHANNEL_1, compare_ticks);
    if (HAL_TIM_GenerateEvent(&htim17, TIM_EVENTSOURCE_UPDATE) != HAL_OK)
    {
        Error_Handler();
    }

    current_freq = target_frequency;
    current_duty = target_duty;
    pwm_applied = 1U;
}

/**
 * @brief  根据 TIM2 DMA 捕获周期计算输入信号频率
 * @param  samples TIM2 输入捕获 DMA 缓冲区
 * @return 捕获频率，未收到有效周期时返回 0
 */
static uint32_t calculate_capture_frequency(const uint32_t *samples)
{
    uint64_t period_sum = 0;
    uint32_t valid_count = 0;

    for (uint32_t index = 0; index < TIM_APP_CAPTURE_SAMPLE_COUNT; index++)
    {
        /* DMA 尚未填满时忽略初始 0，避免把无效数据纳入周期均值。 */
        if (samples[index] != 0U)
        {
            period_sum += samples[index];
            valid_count++;
        }
    }

    if (valid_count == 0U)
    {
        return 0U;
    }

    period_sum /= valid_count;
    return (uint32_t)((PWM_COUNTER_HZ + period_sum / 2U) / period_sum);
}

/**
 * @brief  输入捕获计算与频率异常判定调度函数
 * @param  无
 * @retval 无
 */
void tim_proc(void)
{
    uint32_t captured_frequency;
    uint32_t frequency_difference;
    uint8_t current_abnormal;

    captured_frequency = calculate_capture_frequency(tim_ic_buffer[0]);
    tim_ic_val[0] = captured_frequency;

    if (current_freq >= captured_frequency)
    {
        frequency_difference = current_freq - captured_frequency;
    }
    else
    {
        frequency_difference = captured_frequency - current_freq;
    }

    current_abnormal = (frequency_difference > 1000U) ? 1U : 0U;
    /* 只在正常到异常的上升沿保存快照，持续异常期间不重复覆盖。 */
    if ((current_abnormal != 0U) && (abnormal_flag == 0U))
    {
        stat_CF = current_freq;
        stat_CD = current_duty;
        stat_DF = captured_frequency;
        stat_XF = frequency_difference;
        stat_runtime = runtime_seconds;
    }

    abnormal_flag = current_abnormal;
}
