#include "key_app.h"

#define KEY_B1_MASK (1U << 0)
#define KEY_B2_MASK (1U << 1)
#define KEY_B3_MASK (1U << 2)
#define KEY_B4_MASK (1U << 3)
#define KEY_DEBOUNCE_SAMPLES 3U
#define KEY_LONG_PRESS_MS 2000UL

static uint8_t debounce_candidate = 0;
static uint8_t debounce_count = 0;
static uint8_t stable_keys = 0;
static uint8_t previous_keys = 0;

static uint8_t b2_monitor_press_active = 0;
static uint32_t b2_pressed_at = 0;

static pwm_parameters_t parameter_draft;

/**
 * @brief  读取四个按键的原始按下状态
 * @param  无
 * @return 位掩码形式的按键状态
 */
static uint8_t key_read_raw(void)
{
    uint8_t keys = 0;

    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_0) == GPIO_PIN_RESET)
    {
        keys |= KEY_B1_MASK;
    }
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_1) == GPIO_PIN_RESET)
    {
        keys |= KEY_B2_MASK;
    }
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_2) == GPIO_PIN_RESET)
    {
        keys |= KEY_B3_MASK;
    }
    if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == GPIO_PIN_RESET)
    {
        keys |= KEY_B4_MASK;
    }

    return keys;
}

/**
 * @brief  更新按键防抖后的稳定状态
 * @param  无
 * @retval 无
 */
static void key_update_debounced_state(void)
{
    uint8_t raw_keys = key_read_raw();

    if (raw_keys != debounce_candidate)
    {
        debounce_candidate = raw_keys;
        debounce_count = 1U;
        return;
    }

    if (debounce_count < KEY_DEBOUNCE_SAMPLES)
    {
        debounce_count++;
    }
    if (debounce_count == KEY_DEBOUNCE_SAMPLES)
    {
        /* 连续三次采样一致后才接受新状态，避免机械抖动重复触发。 */
        stable_keys = debounce_candidate;
    }
}

/**
 * @brief  校验参数草稿是否满足题目约束
 * @param  无
 * @return 1 表示合法，0 表示非法
 */
static uint8_t parameter_draft_is_valid(void)
{
    uint32_t duty_span;
    uint32_t frequency_span;

    if ((parameter_draft.duty_limit_pct <= 10U) ||
        (parameter_draft.frequency_limit_hz <= 1000U))
    {
        return 0U;
    }

    duty_span = parameter_draft.duty_limit_pct - 10U;
    frequency_span = parameter_draft.frequency_limit_hz - 1000U;

    if ((parameter_draft.duty_step_pct >=
         parameter_draft.duty_limit_pct) ||
        (parameter_draft.frequency_step_hz >=
         parameter_draft.frequency_limit_hz))
    {
        return 0U;
    }

    if ((parameter_draft.duty_step_pct > duty_span) ||
        (parameter_draft.frequency_step_hz > frequency_span))
    {
        return 0U;
    }

    return 1U;
}

/**
 * @brief  增加当前选中的参数草稿值
 * @param  无
 * @retval 无
 */
static void increase_selected_parameter(void)
{
    switch (selected_param)
    {
        case PARAM_DS:
            if (parameter_draft.duty_step_pct < 100U)
            {
                parameter_draft.duty_step_pct++;
            }
            break;

        case PARAM_DR:
            if (parameter_draft.duty_limit_pct <= 90U)
            {
                parameter_draft.duty_limit_pct += 10U;
            }
            break;

        case PARAM_FS:
            if (parameter_draft.frequency_step_hz <= UINT32_MAX - 100U)
            {
                parameter_draft.frequency_step_hz += 100U;
            }
            break;

        case PARAM_FR:
            if (parameter_draft.frequency_limit_hz <= UINT32_MAX - 1000U)
            {
                parameter_draft.frequency_limit_hz += 1000U;
            }
            break;
    }
}

/**
 * @brief  减少当前选中的参数草稿值
 * @param  无
 * @retval 无
 */
static void decrease_selected_parameter(void)
{
    switch (selected_param)
    {
        case PARAM_DS:
            if (parameter_draft.duty_step_pct > 1U)
            {
                parameter_draft.duty_step_pct--;
            }
            break;

        case PARAM_DR:
            if (parameter_draft.duty_limit_pct > 10U)
            {
                parameter_draft.duty_limit_pct -= 10U;
            }
            break;

        case PARAM_FS:
            if (parameter_draft.frequency_step_hz > 100U)
            {
                parameter_draft.frequency_step_hz -= 100U;
            }
            break;

        case PARAM_FR:
            if (parameter_draft.frequency_limit_hz > 1000U)
            {
                parameter_draft.frequency_limit_hz -= 1000U;
            }
            break;
    }
}

/**
 * @brief  按题目顺序切换界面并处理参数提交
 * @param  无
 * @retval 无
 */
static void switch_interface(void)
{
    if (current_ui == UI_PARAM)
    {
        /* 编辑期间不修改活动参数；退出时合法才一次性提交。 */
        if (parameter_draft_is_valid() != 0U)
        {
            pwm_parameters = parameter_draft;
        }
        current_ui = UI_MONITOR;
        return;
    }

    current_ui = (ui_mode_t)(current_ui + 1);
    if (current_ui == UI_PARAM)
    {
        /* 每次进入参数界面都从当前活动参数创建新的编辑草稿。 */
        parameter_draft = pwm_parameters;
        selected_param = PARAM_DS;
    }
}

/**
 * @brief  在监控界面处理 B2 松开事件
 * @param  now 当前 HAL 毫秒时基
 * @retval 无
 */
static void handle_b2_release(uint32_t now)
{
    uint32_t held_ms;

    if (b2_monitor_press_active == 0U)
    {
        return;
    }

    held_ms = now - b2_pressed_at;
    b2_monitor_press_active = 0U;

    if (held_ms > KEY_LONG_PRESS_MS)
    {
        /* 长按只复位运行时长，不再执行短按的锁定切换。 */
        runtime_reset();
    }
    else
    {
        system_locked ^= 1U;
    }
}

/**
 * @brief  按键扫描与功能调度函数
 * @param  无
 * @retval 无
 */
void key_proc(void)
{
    uint8_t key_down;
    uint8_t key_up;
    uint32_t now = HAL_GetTick();

    key_update_debounced_state();
    key_down = stable_keys & (uint8_t)~previous_keys;
    key_up = (uint8_t)~stable_keys & previous_keys;
    previous_keys = stable_keys;

    if ((key_down & KEY_B1_MASK) != 0U)
    {
        switch_interface();
    }

    if ((key_down & KEY_B2_MASK) != 0U)
    {
        if (current_ui == UI_MONITOR)
        {
            b2_pressed_at = now;
            b2_monitor_press_active = 1U;
        }
        else if (current_ui == UI_PARAM)
        {
            selected_param = (param_select_t)((selected_param + 1) % 4);
        }
    }

    if (((key_up & KEY_B2_MASK) != 0U) && (current_ui == UI_MONITOR))
    {
        handle_b2_release(now);
    }

    if (current_ui == UI_PARAM)
    {
        if ((key_down & KEY_B3_MASK) != 0U)
        {
            increase_selected_parameter();
        }
        if ((key_down & KEY_B4_MASK) != 0U)
        {
            decrease_selected_parameter();
        }
    }
}

/**
 * @brief  获取参数界面当前显示的编辑草稿
 * @param  parameters 参数草稿输出位置
 * @retval 无
 */
void key_app_get_parameter_draft(pwm_parameters_t *parameters)
{
    *parameters = parameter_draft;
}
