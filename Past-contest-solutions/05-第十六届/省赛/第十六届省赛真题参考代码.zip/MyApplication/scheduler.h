#ifndef SCHEDULER_H
#define SCHEDULER_H

#include "bsp_system.h"

#ifdef __cplusplus
extern "C" {
#endif

void scheduler_init(void); /* 时间片调度器初始化函数 */
void scheduler_run(void);  /* 时间片调度器运行函数 */

#ifdef __cplusplus
}
#endif

#endif /* SCHEDULER_H */
