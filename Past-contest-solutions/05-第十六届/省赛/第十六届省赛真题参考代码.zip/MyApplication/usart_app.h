#ifndef USART_APP_H
#define USART_APP_H

#include "bsp_system.h"

#ifdef __cplusplus
extern "C" {
#endif

void uart_proc(void); /* 串口接收数据调度函数 */

#ifdef __cplusplus
}
#endif

#endif /* USART_APP_H */
