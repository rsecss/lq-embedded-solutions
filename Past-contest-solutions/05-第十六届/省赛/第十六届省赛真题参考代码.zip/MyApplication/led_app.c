#include "led_app.h"

#define LED_OUTPUT_PINS                                                     \
    (GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_11 | GPIO_PIN_12 |   \
     GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15)

/**
 * @brief  将 LED 状态写入板载锁存电路
 * @param  led_state LD1~LD8 对应的位状态
 * @retval 无
 */
static void led_display(uint8_t led_state)
{
    static uint8_t previous_state = 0xFFU;

    if (led_state == previous_state)
    {
        return;
    }

    HAL_GPIO_WritePin(GPIOC, LED_OUTPUT_PINS, GPIO_PIN_SET);
    if (led_state != 0U)
    {
        HAL_GPIO_WritePin(GPIOC, (uint16_t)(led_state << 8), GPIO_PIN_RESET);
    }
    /* PD2 上升沿把 PC8~PC15 的低有效电平锁存到 LED。 */
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, GPIO_PIN_SET);
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, GPIO_PIN_RESET);
    previous_state = led_state;
}

/**
 * @brief  根据界面、锁定和异常状态刷新 LED
 * @param  无
 * @retval 无
 */
void led_proc(void)
{
    uint8_t led_state = 0;

    if (current_ui == UI_MONITOR)
    {
        led_state |= 1U << 0;
    }
    if (system_locked != 0U)
    {
        led_state |= 1U << 1;
    }
    if (abnormal_flag != 0U)
    {
        led_state |= 1U << 2;
    }

    led_display(led_state);
}
