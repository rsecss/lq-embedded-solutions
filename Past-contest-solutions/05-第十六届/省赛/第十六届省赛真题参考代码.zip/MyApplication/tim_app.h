#ifndef TIM_APP_H
#define TIM_APP_H

#define TIM_APP_CAPTURE_CHANNEL_COUNT 2U
#define TIM_APP_CAPTURE_SAMPLE_COUNT 64U

#include "bsp_system.h"

#ifdef __cplusplus
extern "C" {
#endif

void pwm_update(uint16_t frequency_adc, uint16_t duty_adc); /* PWM 阶梯更新函数 */
void tim_proc(void);                                        /* 输入捕获与异常判定函数 */

#ifdef __cplusplus
}
#endif

#endif /* TIM_APP_H */
