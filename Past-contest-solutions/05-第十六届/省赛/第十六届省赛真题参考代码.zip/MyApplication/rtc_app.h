#ifndef RTC_APP_H
#define RTC_APP_H

#include "bsp_system.h"

#ifdef __cplusplus
extern "C" {
#endif

void rtc_proc(void);     /* 系统运行时长更新函数 */
void runtime_reset(void); /* 系统运行时长复位函数 */

#ifdef __cplusplus
}
#endif

#endif /* RTC_APP_H */
