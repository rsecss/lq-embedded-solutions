#include "lcd_app.h"

#define LCD_LINE_CHARACTER_COUNT 20U

ui_mode_t current_ui = UI_MONITOR;
param_select_t selected_param = PARAM_DS;

/**
 * @brief  格式化并显示固定宽度的 LCD 行
 * @param  line LCD 行号
 * @param  format 格式化字符串
 * @param  ... 格式化参数
 * @retval 无
 */
static void lcd_write_line(uint8_t line, const char *format, ...)
{
    char content[LCD_LINE_CHARACTER_COUNT + 1U] = {0};
    char padded[LCD_LINE_CHARACTER_COUNT + 1U];
    size_t length;
    va_list arguments;

    va_start(arguments, format);
    vsnprintf(content, sizeof(content), format, arguments);
    va_end(arguments);

    memset(padded, ' ', LCD_LINE_CHARACTER_COUNT);
    padded[LCD_LINE_CHARACTER_COUNT] = '\0';
    length = strlen(content);
    if (length > LCD_LINE_CHARACTER_COUNT)
    {
        length = LCD_LINE_CHARACTER_COUNT;
    }
    memcpy(padded, content, length);

    /* 每次写满 20 个字符，避免短数据覆盖长数据后残留字符。 */
    LCD_DisplayStringLine(line, (u8 *)padded);
}

/**
 * @brief  将系统运行秒数格式化为 xxHyyMzzS
 * @param  text 格式化结果缓冲区
 * @param  total_seconds 系统运行总秒数
 * @retval 无
 */
static void format_runtime(char *text, uint32_t total_seconds)
{
    uint32_t hours = total_seconds / 3600U;
    uint32_t minutes = total_seconds % 3600U / 60U;
    uint32_t seconds = total_seconds % 60U;

    snprintf(text, 16, "%02luH%02luM%02luS", (unsigned long)hours,
             (unsigned long)minutes, (unsigned long)seconds);
}

/**
 * @brief  刷新监控界面
 * @param  无
 * @retval 无
 */
static void lcd_show_monitor(void)
{
    char runtime_text[16];

    format_runtime(runtime_text, runtime_seconds);
    lcd_write_line(Line1, "       PWM");
    lcd_write_line(Line3, "   CF=%luHz", (unsigned long)current_freq);
    lcd_write_line(Line4, "   CD=%lu%%", (unsigned long)current_duty);
    lcd_write_line(Line5, "   DF=%luHz", (unsigned long)tim_ic_val[0]);
    lcd_write_line(Line6, "   ST=%s", system_locked ? "LOCK" : "UNLOCK");
    lcd_write_line(Line7, "   %s", runtime_text);
}

/**
 * @brief  刷新统计界面
 * @param  无
 * @retval 无
 */
static void lcd_show_statistics(void)
{
    char runtime_text[16];

    format_runtime(runtime_text, stat_runtime);
    lcd_write_line(Line1, "       RECD");
    lcd_write_line(Line3, "   CF=%luHz", (unsigned long)stat_CF);
    lcd_write_line(Line4, "   CD=%lu%%", (unsigned long)stat_CD);
    lcd_write_line(Line5, "   DF=%luHz", (unsigned long)stat_DF);
    lcd_write_line(Line6, "   XF=%luHz", (unsigned long)stat_XF);
    lcd_write_line(Line7, "   %s", runtime_text);
}

/**
 * @brief  刷新参数界面
 * @param  无
 * @retval 无
 */
static void lcd_show_parameters(void)
{
    pwm_parameters_t draft;

    key_app_get_parameter_draft(&draft);
    lcd_write_line(Line1, "       PARA");
    lcd_write_line(Line3, "   DS=%lu%%", (unsigned long)draft.duty_step_pct);
    lcd_write_line(Line4, "   DR=%lu%%", (unsigned long)draft.duty_limit_pct);
    lcd_write_line(Line5, "   FS=%luHz",
                   (unsigned long)draft.frequency_step_hz);
    lcd_write_line(Line6, "   FR=%luHz",
                   (unsigned long)draft.frequency_limit_hz);
    lcd_write_line(Line7, "");
}

/**
 * @brief  LCD 界面刷新调度函数
 * @param  无
 * @retval 无
 */
void lcd_proc(void)
{
    switch (current_ui)
    {
        case UI_MONITOR:
            lcd_show_monitor();
            break;

        case UI_STAT:
            lcd_show_statistics();
            break;

        case UI_PARAM:
            lcd_show_parameters();
            break;
    }
}
