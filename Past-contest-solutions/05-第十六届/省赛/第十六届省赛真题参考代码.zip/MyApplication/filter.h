#ifndef FILTER_H
#define FILTER_H

#include "bsp_system.h"

#ifdef __cplusplus
extern "C" {
#endif

void limit_filter(uint32_t *samples, int32_t sample_count,
                  uint32_t minimum, uint32_t maximum); /* 限幅滤波函数 */
uint32_t median_filter(uint32_t *samples, int sample_count);  /* 中值滤波函数 */
uint32_t average_filter(uint32_t *samples, int sample_count); /* 算术平均滤波函数 */
uint32_t adc_filter(uint32_t current_sample);                 /* 一阶 ADC 滤波函数 */

#ifdef __cplusplus
}
#endif

#endif /* FILTER_H */
