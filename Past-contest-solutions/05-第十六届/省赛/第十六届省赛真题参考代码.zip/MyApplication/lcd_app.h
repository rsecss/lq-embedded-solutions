#ifndef LCD_APP_H
#define LCD_APP_H

#include "bsp_system.h"

#ifdef __cplusplus
extern "C" {
#endif

void lcd_proc(void); /* LCD 界面刷新调度函数 */

#ifdef __cplusplus
}
#endif

#endif /* LCD_APP_H */
