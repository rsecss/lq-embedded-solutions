#include "rtc_app.h"

uint32_t runtime_seconds = 0;

static uint32_t runtime_tick_base = 0;

/**
 * @brief  更新系统运行时长
 * @param  无
 * @retval 无
 */
void rtc_proc(void)
{
    uint32_t now = HAL_GetTick();

    while (now - runtime_tick_base >= 1000U)
    {
        /* 累加固定 1000ms 基准，避免调度延迟造成长期计时漂移。 */
        runtime_tick_base += 1000U;
        runtime_seconds++;
    }
}

/**
 * @brief  将系统运行时长及毫秒基准同时复位
 * @param  无
 * @retval 无
 */
void runtime_reset(void)
{
    runtime_seconds = 0;
    runtime_tick_base = HAL_GetTick();
}
