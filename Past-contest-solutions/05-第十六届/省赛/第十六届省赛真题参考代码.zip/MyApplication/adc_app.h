#ifndef ADC_APP_H
#define ADC_APP_H

#define ADC_APP_CHANNEL_COUNT 2U
#define ADC_APP_SAMPLE_COUNT 50U

#include "bsp_system.h"

#ifdef __cplusplus
extern "C" {
#endif

void adc_proc(void);        /* ADC 采样与 PWM 更新调度函数 */

#ifdef __cplusplus
}
#endif

#endif /* ADC_APP_H */
