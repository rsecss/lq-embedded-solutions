import sys
import serial
import serial.tools.list_ports
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                           QHBoxLayout, QLabel, QPushButton, QComboBox, 
                           QLineEdit, QGridLayout, QMessageBox, QTextEdit)
from PyQt5.QtCore import Qt, QTimer, pyqtSignal, QObject
import pyqtgraph as pg
import numpy as np

class SerialThread(QObject):
    received = pyqtSignal(str)  # 定义信号
    
    def __init__(self, serial_port):
        super().__init__()
        self.serial_port = serial_port
        self.is_running = True
        
    def run(self):
        while self.is_running and self.serial_port and self.serial_port.is_open:
            try:
                if self.serial_port.in_waiting:
                    data = self.serial_port.readline().decode().strip()
                    if data:
                        self.received.emit(data)  # 发送信号
            except Exception as e:
                print(f"接收数据错误: {str(e)}")
                break
                
    def stop(self):
        self.is_running = False

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("运动控制系统上位机")
        self.resize(1200, 800)
        
        # 初始化变量
        self.serial_port = None
        self.serial_thread = None
        self.thread = None
        self.coordinate_list = []  # 存储所有坐标点
        self.current_pos = (0, 0)  # 当前位置
        self.target_pos = (0, 0)   # 目标位置
        self.path_points = []      # 存储运动轨迹点
        self.speed = 0.0          # 当前速度
        self.total_distance = 0.0  # 总距离
        self.total_time = 0.0     # 运行时间
        
        # 创建主窗口部件
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        
        # 创建布局
        self.main_layout = QHBoxLayout(self.central_widget)
        self.left_layout = QVBoxLayout()
        self.right_layout = QVBoxLayout()
        
        # 设置左右布局的比例
        self.main_layout.addLayout(self.left_layout, 7)
        self.main_layout.addLayout(self.right_layout, 3)
        
        # 创建图形显示区域
        self.setup_plot_area()
        
        # 创建控制面板
        self.setup_control_panel()
        
        # 创建定时器用于更新显示
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.update_plot)
        self.update_timer.start(100)  # 100ms更新一次
        
    def setup_plot_area(self):
        """设置图形显示区域"""
        # 创建绘图窗口
        self.plot_widget = pg.PlotWidget()
        self.plot_widget.setBackground('w')
        self.plot_widget.setAspectLocked(True)
        self.plot_widget.showGrid(x=True, y=True)
        self.plot_widget.setXRange(0, 1000)
        self.plot_widget.setYRange(0, 1000)
        
        # 创建散点图项用于显示坐标点
        self.target_points_scatter = pg.ScatterPlotItem(pen=pg.mkPen(None), brush=pg.mkBrush(255, 0, 0, 120))  # 红色：所有目标点
        self.current_pos_scatter = pg.ScatterPlotItem(pen=pg.mkPen(None), brush=pg.mkBrush(0, 255, 0, 200))    # 绿色：当前位置
        self.target_pos_scatter = pg.ScatterPlotItem(pen=pg.mkPen(None), brush=pg.mkBrush(0, 0, 255, 200))     # 蓝色：当前目标点
        
        # 创建路径线
        self.path_line = pg.PlotDataItem(pen=pg.mkPen('b', width=2))
        
        # 添加图形项到绘图窗口
        self.plot_widget.addItem(self.target_points_scatter)
        self.plot_widget.addItem(self.current_pos_scatter)
        self.plot_widget.addItem(self.target_pos_scatter)
        self.plot_widget.addItem(self.path_line)
        
        self.left_layout.addWidget(self.plot_widget)
        
    def setup_control_panel(self):
        """设置控制面板"""
        # 串口设置区域
        serial_group = QWidget()
        serial_layout = QGridLayout(serial_group)
        
        # 串口选择
        self.port_combo = QComboBox()
        self.baud_combo = QComboBox()  # 添加波特率选择
        self.baud_combo.addItems(['9600', '19200', '38400', '57600', '115200'])
        self.baud_combo.setCurrentText('115200')  # 默认115200
        self.refresh_button = QPushButton("刷新")
        self.connect_button = QPushButton("连接")
        self.refresh_button.clicked.connect(self.refresh_ports)
        self.connect_button.clicked.connect(self.toggle_connection)
        
        serial_layout.addWidget(QLabel("串口:"), 0, 0)
        serial_layout.addWidget(self.port_combo, 0, 1)
        serial_layout.addWidget(QLabel("波特率:"), 0, 2)
        serial_layout.addWidget(self.baud_combo, 0, 3)
        serial_layout.addWidget(self.refresh_button, 0, 4)
        serial_layout.addWidget(self.connect_button, 0, 5)
        
        # 指令输入区域
        cmd_group = QWidget()
        cmd_layout = QGridLayout(cmd_group)
        
        self.cmd_input = QLineEdit()
        self.send_button = QPushButton("发送")
        self.send_button.clicked.connect(self.send_command)
        
        cmd_layout.addWidget(QLabel("指令:"), 0, 0)
        cmd_layout.addWidget(self.cmd_input, 0, 1)
        cmd_layout.addWidget(self.send_button, 0, 2)
        
        # 控制按钮区域
        control_group = QWidget()
        control_layout = QHBoxLayout(control_group)
        
        self.clear_path_button = QPushButton("清除轨迹")
        self.reset_button = QPushButton("一键复位")
        self.clear_path_button.clicked.connect(self.clear_path)
        self.reset_button.clicked.connect(self.reset_all)
        
        control_layout.addWidget(self.clear_path_button)
        control_layout.addWidget(self.reset_button)
        
        # 数据接收显示区域
        recv_group = QWidget()
        recv_layout = QVBoxLayout(recv_group)
        
        self.recv_text = QTextEdit()
        self.recv_text.setReadOnly(True)  # 设置为只读
        self.recv_text.setMaximumHeight(200)  # 限制高度
        self.clear_recv_button = QPushButton("清除接收")
        self.clear_recv_button.clicked.connect(self.clear_recv_data)
        
        recv_layout.addWidget(QLabel("数据接收:"))
        recv_layout.addWidget(self.recv_text)
        recv_layout.addWidget(self.clear_recv_button)
        
        # 状态显示区域
        status_group = QWidget()
        status_layout = QGridLayout(status_group)
        
        self.status_label = QLabel("状态: 未连接")
        self.current_pos_label = QLabel("当前位置: (0, 0)")
        self.target_pos_label = QLabel("目标位置: (0, 0)")
        self.speed_label = QLabel("速度: 0")
        self.distance_label = QLabel("总距离: 0")
        self.time_label = QLabel("运行时间: 0")
        
        status_layout.addWidget(self.status_label, 0, 0)
        status_layout.addWidget(self.current_pos_label, 1, 0)
        status_layout.addWidget(self.target_pos_label, 2, 0)
        status_layout.addWidget(self.speed_label, 3, 0)
        status_layout.addWidget(self.distance_label, 4, 0)
        status_layout.addWidget(self.time_label, 5, 0)
        
        # 添加所有组件到右侧布局
        self.right_layout.addWidget(serial_group)
        self.right_layout.addWidget(cmd_group)
        self.right_layout.addWidget(control_group)
        self.right_layout.addWidget(recv_group)
        self.right_layout.addWidget(status_group)
        self.right_layout.addStretch()
        
        # 初始化串口列表
        self.refresh_ports()
        
    def refresh_ports(self):
        """刷新可用串口列表"""
        self.port_combo.clear()
        ports = [port.device for port in serial.tools.list_ports.comports()]
        self.port_combo.addItems(ports)
        
    def toggle_connection(self):
        """切换串口连接状态"""
        if self.serial_port is None or not self.serial_port.is_open:
            try:
                port = self.port_combo.currentText()
                baud = int(self.baud_combo.currentText())  # 获取选择的波特率
                self.serial_port = serial.Serial(port, baud, timeout=0.1)
                self.connect_button.setText("断开")
                self.status_label.setText("状态: 已连接")
                # 启动串口接收线程
                self.start_receive_thread()
            except Exception as e:
                QMessageBox.critical(self, "错误", f"无法连接串口: {str(e)}")
        else:
            if self.serial_thread:
                self.serial_thread.stop()
            if self.serial_port:
                self.serial_port.close()
            self.serial_port = None
            self.connect_button.setText("连接")
            self.status_label.setText("状态: 未连接")
            
    def send_command(self):
        """发送指令到下位机"""
        if self.serial_port and self.serial_port.is_open:
            cmd = self.cmd_input.text().strip()
            if cmd:
                try:
                    self.serial_port.write(f"{cmd}\n".encode())
                    # 添加发送的数据到显示区域
                    self.recv_text.append(f"发送: {cmd}")
                    self.cmd_input.clear()
                except Exception as e:
                    print(f"发送指令错误: {str(e)}")
                    
    def process_received_data(self, data):
        """处理接收到的数据"""
        try:
            # 添加接收到的原始数据到显示区域
            self.recv_text.append(f"接收: {data}")
            
            if data.startswith("$"):
                parts = data.strip().split(",")
                if len(parts) >= 2:
                    cmd = parts[0]
                    if cmd == "$STATUS":
                        self.status_label.setText(f"状态: {parts[1]}")
                    elif cmd == "$POS" and len(parts) >= 3:
                        x, y = int(parts[1]), int(parts[2])
                        self.current_pos = (x, y)
                        self.current_pos_label.setText(f"当前位置: ({x}, {y})")
                        self.path_points.append((x, y))
                    elif cmd == "$TARGET" and len(parts) >= 3:
                        x, y = int(parts[1]), int(parts[2])
                        self.target_pos = (x, y)
                        self.target_pos_label.setText(f"目标位置: ({x}, {y})")
                        # 更新目标点列表
                        if (x, y) not in self.coordinate_list:
                            self.coordinate_list.append((x, y))
                    elif cmd == "$SPEED":
                        self.speed = float(parts[1])
                        self.speed_label.setText(f"速度: {self.speed:.2f}")
                    elif cmd == "$DIST":
                        self.total_distance = float(parts[1])
                        self.distance_label.setText(f"总距离: {self.total_distance:.2f}")
                    elif cmd == "$TIME":
                        self.total_time = int(parts[1])
                        self.time_label.setText(f"运行时间: {self.total_time}s")
                    
                    # 更新图形显示
                    self.update_plot()
        except Exception as e:
            print(f"处理数据错误: {str(e)}")
            
    def update_plot(self):
        """更新图形显示"""
        # 更新所有目标点
        if self.coordinate_list:
            x = [p[0] for p in self.coordinate_list]
            y = [p[1] for p in self.coordinate_list]
            self.target_points_scatter.setData(x=x, y=y)
        else:
            self.target_points_scatter.clear()
            
        # 更新当前位置
        if self.current_pos == (0, 0):
            self.current_pos_scatter.clear()
        else:
            self.current_pos_scatter.setData(x=[self.current_pos[0]], 
                                           y=[self.current_pos[1]])
        
        # 更新目标位置
        if self.target_pos == (0, 0):
            self.target_pos_scatter.clear()
        else:
            self.target_pos_scatter.setData(x=[self.target_pos[0]], 
                                          y=[self.target_pos[1]])
        
        # 更新路径
        if self.path_points:
            x = [p[0] for p in self.path_points]
            y = [p[1] for p in self.path_points]
            self.path_line.setData(x=x, y=y)
        else:
            self.path_line.clear()
            
    def start_receive_thread(self):
        """启动串口接收线程"""
        from threading import Thread
        self.serial_thread = SerialThread(self.serial_port)
        self.serial_thread.received.connect(self.process_received_data)
        
        self.thread = Thread(target=self.serial_thread.run, daemon=True)
        self.thread.start()
        
    def clear_recv_data(self):
        """清除接收区数据"""
        self.recv_text.clear()
        
    def closeEvent(self, event):
        """窗口关闭事件"""
        if self.serial_thread:
            self.serial_thread.stop()
        if self.serial_port and self.serial_port.is_open:
            self.serial_port.close()
        event.accept()
        
    def clear_path(self):
        """清除轨迹和所有坐标点"""
        self.path_points.clear()        # 清除轨迹点
        self.coordinate_list.clear()    # 清除所有目标坐标点
        self.current_pos = (0, 0)       # 重置当前位置
        self.target_pos = (0, 0)        # 重置目标位置
        
        # 更新标签显示
        self.current_pos_label.setText("当前位置: (0, 0)")
        self.target_pos_label.setText("目标位置: (0, 0)")
        
        # 清除所有图形项
        self.target_points_scatter.clear()
        self.current_pos_scatter.clear()
        self.target_pos_scatter.clear()
        self.path_line.clear()
        
        # 更新图形显示
        self.update_plot()
        
        # 发送清除指令到下位机
        # if self.serial_port and self.serial_port.is_open:
        #     self.send_command("clear")   # 发送清除指令
        
    def reset_all(self):
        """一键复位"""
        # 清除所有数据
        self.path_points.clear()
        self.current_pos = (0, 0)
        self.target_pos = (0, 0)
        self.speed = 0.0
        self.total_distance = 0.0
        self.total_time = 0
        
        # 更新显示
        self.status_label.setText("状态: 未连接")
        self.current_pos_label.setText("当前位置: (0, 0)")
        self.target_pos_label.setText("目标位置: (0, 0)")
        self.speed_label.setText("速度: 0")
        self.distance_label.setText("总距离: 0")
        self.time_label.setText("运行时间: 0")
        
        # 清除图形
        self.update_plot()
        
        # # 发送复位指令到下位机
        # if self.serial_port and self.serial_port.is_open:
        #     self.send_command("reset")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_()) 