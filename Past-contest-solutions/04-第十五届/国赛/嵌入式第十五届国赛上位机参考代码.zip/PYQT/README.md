# 运动控制系统上位机

## 功能特点

1. 实时显示运动轨迹
2. 坐标点添加和管理
3. 串口通信功能
4. 系统状态监控
5. 参数实时显示

## 安装依赖

```bash
pip install -r requirements.txt
```

## 运行程序

```bash
python main.py
```

## 使用说明

1. 串口连接
   - 选择正确的串口
   - 点击"连接"按钮
   - 连接成功后状态会显示"已连接"

2. 添加坐标点
   - 在X和Y输入框中输入坐标值（0-999）
   - 点击"添加坐标"按钮
   - 坐标点会显示在图形区域中

3. 运动控制
   - 添加坐标点后，系统会自动规划路径
   - 运动过程中会实时显示当前位置和轨迹
   - 可以通过"清除坐标"按钮清除所有点

4. 状态显示
   - 当前位置
   - 目标位置
   - 系统状态
   - 运行时间
   - 总距离

## 图形界面说明

- 红色点：设定的坐标点
- 绿色点：当前位置
- 蓝色点：目标位置
- 蓝色线：运动轨迹

## 通信协议

1. 发送坐标点：(x,y)
2. 查询状态：?
3. 查询位置：#

## 注意事项

1. 确保串口波特率设置为9600
2. 坐标范围限制在0-999之间
3. 运行程序前请确保已安装所有依赖 

## 下位机代码

```c
/**
 * @brief 上报系统信息到上位机
 * 定期发送当前状态、位置、速度等信息
 */
void report_system_info(void)
{
    static uint32_t last_report_time = 0;
    uint32_t current_time = HAL_GetTick();
    
    // 每100ms上报一次信息
    if(current_time - last_report_time >= 100)
    {
        last_report_time = current_time;
        
        char buffer[64];
        
        // 上报状态信息
        switch(device_state)
        {
            case IDLE:
                printf("$STATUS,IDLE\n");
                break;
            case BUSY:
                printf("$STATUS,BUSY\n");
                break;
            case WAIT:
                printf("$STATUS,WAIT\n");
                break;
        }
        
        // 上报位置信息
        sprintf(buffer, "$POS,%d,%d\n", current_pos_x, current_pos_y);
        printf("%s", buffer);
        
        // 上报目标点信息
        sprintf(buffer, "$TARGET,%d,%d\n", target_pos_x, target_pos_y);
        printf("%s", buffer);
        
        // 上报速度信息
        sprintf(buffer, "$SPEED,%.2f\n", speed);
        printf("%s", buffer);
        
        // 上报总距离和运行时间
        sprintf(buffer, "$DIST,%.2f\n", total_distance);
        printf("%s", buffer);
        sprintf(buffer, "$TIME,%lu\n", (uint32_t)total_time);
        printf("%s", buffer);
    }
}

```

