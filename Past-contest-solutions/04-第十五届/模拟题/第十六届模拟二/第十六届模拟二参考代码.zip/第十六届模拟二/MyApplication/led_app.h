#ifndef LED_APP_H
#define LED_APP_H

#include "bsp_system.h"

void led_proc(void);

#endif
