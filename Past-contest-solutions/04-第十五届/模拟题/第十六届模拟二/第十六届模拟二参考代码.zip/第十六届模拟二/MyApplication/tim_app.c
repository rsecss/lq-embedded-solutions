#include "tim_app.h"

void pwm_set_duty(float duty, uint8_t tim_x)
{
    switch(tim_x)
    {
        case 16:
            TIM16->CCR1 = (TIM16->ARR + 1) * (duty / 100.0f);
            break;
        case 17:
            TIM17->CCR1 = (TIM17->ARR + 1) * (duty / 100.0f);
            break;
    }
}

void pwm_set_frequency(uint32_t frequency, uint8_t tim_x)
{
    uint32_t clk = 80 * 1000 * 1000;
    
    uint32_t arr_value = 0;
    uint32_t prescaler = 1;
    float duty = 0.0f;
    
    arr_value = clk / (frequency * prescaler) - 1;
    
    if (arr_value > 65535)
    {
        prescaler = (arr_value + 65535) / 65535;
        arr_value = clk / (frequency * prescaler) - 1;
    }
    
    switch(tim_x)
    {
        case 16:
            duty = (float)(TIM16->CCR1) / (TIM16->ARR + 1);
            __HAL_TIM_SET_PRESCALER(&htim16, prescaler - 1);
            TIM16->ARR = arr_value;
            TIM16->CCR1 = (TIM16->ARR + 1) * duty;
            TIM16->EGR = TIM_EGR_UG;
            break;
        case 17:
            duty = (float)(TIM17->CCR1) / (TIM17->ARR + 1);
            __HAL_TIM_SET_PRESCALER(&htim17, prescaler - 1);
            TIM17->ARR = arr_value;
            TIM17->CCR1 = (TIM17->ARR + 1) * duty;
            TIM17->EGR = TIM_EGR_UG;
            break;
    }
}


uint32_t tim_ic_buffers[2][64];
uint32_t tim_ic_value[2];
float pwm_duty = 88.8;
uint32_t pwm_frequency = 8888;

void tim_proc()
{
    tim_ic_value[0] = 0;
    tim_ic_value[1] = 0;
    
    for (uint8_t i = 0; i < 64; i++)
    {
        tim_ic_value[0] += tim_ic_buffers[0][i];
        tim_ic_value[1] += tim_ic_buffers[1][i];
    }
    
    tim_ic_value[0] = (int32_t)(1000000.0f * 64 / (float)tim_ic_value[0]);
    tim_ic_value[1] = (int32_t)(1000000.0f * 64 / (float)tim_ic_value[1]);
    
    for (uint8_t i = 0; i < 2; i++)
    {
        if (tim_ic_value[i] < 500)
        {
            tim_ic_value[i] = 500;
        }
        else if (tim_ic_value[i] > 20000)
        {
            tim_ic_value[i] = 20000;
        }
    }
    
    pwm_set_duty(pwm_duty, 16);
    pwm_set_frequency(pwm_frequency,17);
}
