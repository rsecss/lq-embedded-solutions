#include "lcd_app.h"

void lcd_sprintf(uint8_t line, char * format, ...)
{
    char string[21];
    va_list arg;
    va_start(arg, format);
    vsprintf(string, format, arg);
    va_end(arg);
    LCD_DisplayStringLine(line, (u8 *)string);
}

uint8_t lcd_disp_mode = 0;
control_mode_t mode = KEY;
uint32_t pf_value = 1000;
static const char *string[] = {"KEY", "USART"};
void lcd_proc()
{
    if (lcd_disp_mode == 0)
    {
        lcd_sprintf(Line1, "        DATA");
        lcd_sprintf(Line3, "     F1=%dHZ     ", tim_ic_value[1]);
        lcd_sprintf(Line4, "     F2=%dHZ     ", tim_ic_value[0]);
        lcd_sprintf(Line5, "     MODE=%s     ", string[mode]);
    }
    if (lcd_disp_mode == 1)
    {
        lcd_sprintf(Line1, "        PARA");
        lcd_sprintf(Line3, "      PF=%dHZ    ", pf_value);
        lcd_sprintf(Line4, "                 ");
        lcd_sprintf(Line5, "                 ");
    }
}
