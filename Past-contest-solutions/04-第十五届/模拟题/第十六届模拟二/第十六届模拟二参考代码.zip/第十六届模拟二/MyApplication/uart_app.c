#include "uart_app.h"

uint8_t uart_buffers[128];
uint16_t uart_index = 0;
uint32_t uart_ticks = 0;

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART1)
    {
        uart_ticks = uwTick;
        uart_index++;
        HAL_UART_Receive_IT(&huart1, &uart_buffers[uart_index], 1);
    }
}


void parse_command(char *command)
{
    if (mode == USART)
    {
        if (strcmp((const char *)command, "TF1") == 0)
        {
            HAL_TIM_IC_Start_DMA(&htim3, TIM_CHANNEL_1, &tim_ic_buffers[1][0], 64);
        }
        else if (strcmp((const char *)command, "TF2") == 0)
        {
        HAL_TIM_IC_Start_DMA(&htim2, TIM_CHANNEL_1, &tim_ic_buffers[0][0], 64);
        }
        else if (strcmp((const char *)command, "PF1") == 0)
        {
            HAL_TIM_IC_Stop_DMA(&htim3, TIM_CHANNEL_1);
        }
        else if (strcmp((const char *)command, "PF2") == 0)
        {
            HAL_TIM_IC_Stop_DMA(&htim2, TIM_CHANNEL_1);
        }
        else if (strcmp((const char *)command, "F1") == 0)
        {
            printf("F1:%dHz\n", tim_ic_value[1]);
        }
        else if (strcmp((const char *)command, "F2") == 0)
        {
            printf("F2:%dHz\n", tim_ic_value[0]);
        }
        else
        {
            printf("NULL");
        }
    }
    else if (mode == KEY)
    {
        printf("NULL");
    }
}


void uart_proc()
{
    if (uart_index == 0)
        return;
    if (uwTick - uart_ticks > 100)
    {
        parse_command((char *)uart_buffers);
        memset(uart_buffers, 0, uart_index);
        uart_index = 0;
        huart1.pRxBuffPtr = uart_buffers;
    }
}
