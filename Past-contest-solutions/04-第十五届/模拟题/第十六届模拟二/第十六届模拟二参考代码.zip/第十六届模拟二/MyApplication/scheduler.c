#include "scheduler.h"

uint8_t task_num = 0;

typedef struct {
    void (*task_func)(void);
    uint32_t period_ms;
    uint32_t last_run_time;
}task_t;

static task_t scheduler_tasks[] = {
    {led_proc, 50, 0},
    {key_proc, 20, 0},
    {lcd_proc, 100, 0},
    {uart_proc, 20, 0},
    {adc_proc, 20, 0},
    {tim_proc, 20, 0},
};

void scheduler_init()
{
    task_num = sizeof(scheduler_tasks) /sizeof(task_t);
}

void scheduler_run()
{
    for(uint8_t i = 0; i < task_num; i++)
    {
        uint32_t now_time = uwTick;
        
        if (now_time > scheduler_tasks[i].period_ms + scheduler_tasks[i].last_run_time)
        {
            scheduler_tasks[i].last_run_time = now_time;
            scheduler_tasks[i].task_func();
        }
    }

}
