#ifndef ADC_APP_H
#define ADC_APP_H

#include "bsp_system.h"

void adc_proc(void);

#endif
