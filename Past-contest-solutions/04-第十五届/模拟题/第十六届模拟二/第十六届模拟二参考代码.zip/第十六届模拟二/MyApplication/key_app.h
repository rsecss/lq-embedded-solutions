#ifndef KEY_APP_H
#define KEY_APP_H

#include "bsp_system.h"

void key_proc(void);

#endif
