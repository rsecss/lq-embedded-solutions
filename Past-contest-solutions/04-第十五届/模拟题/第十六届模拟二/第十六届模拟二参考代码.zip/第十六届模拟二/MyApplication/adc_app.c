#include "adc_app.h"

uint32_t adc_buffers[2][30];
float adc_value[2];

void adc_proc()
{
    adc_value[0] = adc_value[1] = 0;
    
    for (uint8_t i = 0; i< 30; i++)
    {
        adc_value[0] += (float)adc_buffers[0][i];
        adc_value[1] += (float)adc_buffers[1][i];
    }
    
    adc_value[0] = adc_value[0] / 30 * 3.3f / 4096;
    adc_value[1] = adc_value[1] / 30 * 3.3f / 4096;
}
