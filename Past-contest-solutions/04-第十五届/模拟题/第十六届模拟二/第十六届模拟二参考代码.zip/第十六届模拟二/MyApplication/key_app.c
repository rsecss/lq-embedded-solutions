#include "key_app.h"

uint8_t key_value = 0;
uint8_t key_old = 0;
uint8_t key_down = 0;
uint8_t key_up = 0;

uint8_t key_read()
{
    uint8_t temp = 0;
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_0) == GPIO_PIN_RESET)
    {
        temp = 1;
    }
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_1) == GPIO_PIN_RESET)
    {
        temp = 2;
    }
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_2) == GPIO_PIN_RESET)
    {
        temp = 3;
    }
    if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == GPIO_PIN_RESET)
    {
        temp = 4;
    }
    
    return temp;
}

uint8_t key_flag[2] = {1,1};

void key_proc()
{
    key_value = key_read();
    key_down = key_value & (key_value ^ key_old);
    key_up = ~key_value & (key_value ^ key_old);
    key_old = key_value;
    
    switch(key_down)
    {
        case 1:
            lcd_disp_mode = (lcd_disp_mode + 1) % 2;
            break;
        case 2:
            mode = (mode == USART) ? KEY : USART;
            break;
        case 3:
            if (lcd_disp_mode == 0 && mode == KEY && key_flag[0] == 1)
            {
                HAL_TIM_IC_Stop_DMA(&htim3, TIM_CHANNEL_1);
                key_flag[0] = 0;
            }
            else if (lcd_disp_mode == 0 && mode == KEY && key_flag[0] == 0)
            {
                HAL_TIM_IC_Start_DMA(&htim3, TIM_CHANNEL_1, &tim_ic_buffers[1][0], 64);
                key_flag[0] = 0;
            }
            else if (lcd_disp_mode == 1)
            {
                pf_value += 1000;
                if (pf_value > 10000)
                {
                    pf_value = 1000;
                }
            }
            break;
        case 4:
            if (lcd_disp_mode == 0 && mode == KEY && key_flag[1] == 1)
            {
                HAL_TIM_IC_Stop_DMA(&htim2, TIM_CHANNEL_1);
                key_flag[1] = 0;
            }
            else if (lcd_disp_mode == 0 && mode == KEY && key_flag[1] == 0)
            {
                HAL_TIM_IC_Start_DMA(&htim2, TIM_CHANNEL_1, &tim_ic_buffers[0][0], 64);
                key_flag[1] = 0;
            }
            else if (lcd_disp_mode == 1)
            {
                pf_value -= 1000;
                if (pf_value < 1000)
                {
                    pf_value = 10000;
                }
            }
            break;
    }
}
