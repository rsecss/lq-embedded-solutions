#ifndef TIM_APP_H
#define TIM_APP_H

#include "bsp_system.h"

void tim_proc(void);

#endif
