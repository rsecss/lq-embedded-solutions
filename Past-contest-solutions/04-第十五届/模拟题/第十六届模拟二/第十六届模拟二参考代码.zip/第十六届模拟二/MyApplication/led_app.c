#include "led_app.h"

void led_disp(uint8_t led)
{
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10 |
                             GPIO_PIN_11 | GPIO_PIN_12 | GPIO_PIN_13 |
                             GPIO_PIN_14 | GPIO_PIN_15, GPIO_PIN_SET);
    //HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, GPIO_PIN_SET);
    //HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, GPIO_PIN_RESET);
    
    HAL_GPIO_WritePin(GPIOC, (uint16_t)(led << 0x08), GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, GPIO_PIN_SET);
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, GPIO_PIN_RESET);
}

uint32_t led_ticks = 0;
void led_proc()
{
    uint8_t led_state = 0x00;
    
    if (lcd_disp_mode == 0)
    {
        led_state |= 0x01;
    }
    else if (lcd_disp_mode == 1)
    {
        led_state |= 0x02;
    }
    
    if (tim_ic_value[0] < pf_value && tim_ic_value[1] < pf_value)
    {
        uint32_t current_time = uwTick - led_ticks;
        led_state |= ((current_time / 100) % 2) ? 0x04 : 0x00;
    }
    
    if(mode == USART)
    {
        led_state |= 0x80;
    }
    
    led_disp(led_state);
}
