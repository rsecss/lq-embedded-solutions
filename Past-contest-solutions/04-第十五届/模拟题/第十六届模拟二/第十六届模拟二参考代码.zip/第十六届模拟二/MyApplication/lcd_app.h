#ifndef LCD_APP_H
#define LCD_APP_H

#include "bsp_system.h"

void lcd_proc(void);

#endif
