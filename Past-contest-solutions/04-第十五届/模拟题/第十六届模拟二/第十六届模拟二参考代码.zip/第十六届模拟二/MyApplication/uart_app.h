#ifndef UART_APP_H
#define UART_APP_H

#include "bsp_system.h"

void uart_proc(void);

#endif
