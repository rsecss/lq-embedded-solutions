#ifndef BSP_SYSTEM_H
#define BSP_SYSTEM_H

#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <stdint.h>

#include "main.h"
#include "usart.h"
#include "tim.h"
#include "lcd.h"

#include "scheduler.h"
#include "led_app.h"
#include "key_app.h"
#include "lcd_app.h"
#include "uart_app.h"
#include "adc_app.h"
#include "tim_app.h"

typedef enum {
    KEY = 0,
    USART = 1,
}control_mode_t;


extern uint8_t uart_buffers[128];
extern uint32_t adc_buffers[2][30];
extern float adc_value[2];
extern uint32_t tim_ic_buffers[2][64];
extern uint32_t tim_ic_value[2];
extern float pwm_duty;
extern uint32_t pwm_frequency;
extern uint8_t lcd_disp_mode;
extern control_mode_t mode;
extern uint32_t pf_value;

#endif

