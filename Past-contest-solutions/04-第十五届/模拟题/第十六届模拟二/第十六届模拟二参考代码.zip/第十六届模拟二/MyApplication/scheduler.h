#ifndef SCHEDULER_H
#define SCHEDULER_H

#include "bsp_system.h"

void scheduler_init(void);
void scheduler_run(void);

#endif
