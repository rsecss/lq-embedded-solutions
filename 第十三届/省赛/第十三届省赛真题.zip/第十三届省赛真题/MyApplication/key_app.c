#include "key_app.h"

static uint8_t key_val = 0;        // 当前按键状态
static uint8_t key_old = 0;        // 上一次按键状态
static uint8_t key_down = 0;       // 按键按下标志
static uint8_t key_up = 0;         // 按键松开标志

/* 底层 */
/**
 * @brief           读取按键状态
 * 
 * @param           无
 * @return          uint8_t: 返回按键编号，0 表示无按键按下，1~4 表示相应按键编号
 */
static uint8_t key_read()
{
    uint8_t temp = 0;

    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_0) == GPIO_PIN_RESET)
        temp = 1;           // 如果引脚状态为 RESET，按键一按下
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_1) == GPIO_PIN_RESET)
        temp = 2;           // 如果引脚状态为 RESET，按键二按下
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_2) == GPIO_PIN_RESET)
        temp = 3;           //如果引脚状态为 RESET，按键三按下
    if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == GPIO_PIN_RESET)
        temp = 4;           // 如果引脚状态为 RESET，按键四按下

    return temp;
}

/* 逻辑层 */
uint32_t key_tick = 0;              // 按键时间戳
uint32_t error_tick = 0;            // 错误时间戳
uint8_t error_count = 0;            // 错误计数

/**
 * @brief           按键控制处理函数（四行代码版本）
 * @param           无
 * @retval          无
 */
void key_proc()
{
    key_val = key_read();
    /* 计算按下的按键（当前按下状态与前一状态异或，并与当前状态相与）*/
    key_down = key_val & (key_val ^ key_old);
    /* 计算松开的按键（当前松开状态与前一状态异或，并与当前状态相与）*/
    key_up = ~key_val & (key_val ^ key_old);
    key_old = key_val;

    if (uwTick - key_tick > 5000 && lcd_display_mode == 1)
    {
        lcd_display_mode = 0;
        memset(password_input, '@', sizeof(password_input));
    }

    /* 密码调整 */
    if (lcd_display_mode == 0 && key_down > 0 && key_down <= 3)
    {
        if (password_input[key_down - 1] == '@')
        {
            password_input[key_down - 1] = '0';
        }
        else if (++password_input[key_down - 1] == '9' + 1)
        {
            password_input[key_down - 1] = '0';
        }
    }

    if (lcd_display_mode == 0 && key_down == 4)
    {
        if (memcmp(password_data, password_input, sizeof(password_input)) == 0)
        {
            lcd_display_mode = 1;
            key_tick = uwTick;
        }
        else
        {
            error_count++;
            if (error_count >= 3)
            {
                error_tick = uwTick;
            }
            memset(password_input, '@', sizeof(password_input));
        }
    }
}
