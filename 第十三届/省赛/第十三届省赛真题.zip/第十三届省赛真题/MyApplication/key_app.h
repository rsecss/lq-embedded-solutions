#ifndef KEY_APP_H
#define KEY_APP_H

#include "bsp_system.h"

#ifdef __cplusplus
extern "C" {
#endif

void key_proc(void);        /* 按键调度函数 */

#ifdef __cplusplus
}
#endif

#endif /* KEY_APP_H */
